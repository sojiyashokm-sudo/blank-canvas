## Goal
Add a "Live Schedule" tab next to "Smart Picks" on the homepage and build a brand-new LiveChart.me-style schedule page with live countdowns, day filters, and rich cards.

## 1. Homepage tab button (`src/routes/index.tsx`)
- Add a fourth pill in the Tabs row, right after **Smart Picks**, labeled **Live Schedule** with the `Radio` Lucide icon (or `Tv`) — same `TabTrigger` styling so it matches exactly.
- Its `TabsContent` renders the new `<LiveSchedule />` component inline so the transition is a smooth tab switch (no full route change), keeping the dashboard feel.
- Include a secondary "Open full page" link to `/schedule` for users who want the dedicated route.

## 2. New dedicated route (`src/routes/schedule.tsx`)
- File-based route `/schedule` with proper `head()` metadata.
- Layout: `SiteHeader` + a back button (`<Link to="/">← Back to home`, ghost style, top-left of main).
- Renders the same `<LiveSchedule />` component (single source of truth).

## 3. `<LiveSchedule />` component (`src/components/live-schedule.tsx`)
LiveChart.me-inspired layout:
- **Day selector row**: 7 pill buttons Mon–Sun, today highlighted with the neon gradient. Clicking filters the grid. An "All week" option as well.
- **"Airing This Season" header** with current season/year badge.
- **Card grid** (responsive 1/2/3 cols): each card shows
  - Cover art (left) + banner tint
  - Title, studio, format
  - Genre chips
  - Streaming/network tags derived from AniList `externalLinks` (Crunchyroll, Netflix, Hulu, Funimation, etc.) with colored badges
  - Synopsis (line-clamped to 3 lines)
  - **Live countdown**: "Ep N airs in 2d 5h 12m 09s" — ticks every second via a single `useEffect` interval updating `Date.now()` state at the component root, so all cards re-render in sync.
  - Score + episode count footer

## 4. Data layer (`src/lib/anilist.ts`)
- Extend `getWeeklySchedule` (or add `getScheduleRich`) to request `description`, `studios`, `externalLinks`, `genres`, `bannerImage` on each `media` — needed for streaming tags + synopsis. Keep existing `AiringEntry` type, add `mediaRich` fields.
- Helper `streamingLinks(externalLinks)` filters to known streaming sites with brand colors.

## 5. Live-feed simulation
- Single `useNow()` hook returning `Date.now()` updated every 1s.
- Countdowns recompute from `airingAt - now`.
- "Airing today" auto-recomputes when the day rolls over because filter derives from `now`.
- React Query `refetchInterval: 5 * 60_000` to refresh the schedule feed itself.

## 6. Back navigation
- Schedule route: prominent `← Back` button.
- Homepage tab variant: just switch tabs (no nav needed).

## Files to add/edit
- `src/routes/index.tsx` — add 4th tab + content
- `src/routes/schedule.tsx` — new route
- `src/components/live-schedule.tsx` — new component
- `src/components/schedule-card.tsx` — new card component
- `src/hooks/use-now.ts` — 1s ticker hook
- `src/lib/anilist.ts` — enrich schedule query

## Out of scope
- No changes to backend/Supabase/watchlist code.
- The existing `/airing` route stays as-is (simpler schedule); new `/schedule` is the rich LiveChart-style view.
