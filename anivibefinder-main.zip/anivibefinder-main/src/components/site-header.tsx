import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Sparkles, Flame, Compass, CalendarClock, Bookmark, LogOut, User as UserIcon, Settings as SettingsIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";

type NavItem = { to: string; label: string; icon: typeof Flame; auth?: boolean };
const navItems: NavItem[] = [
  { to: "/", label: "Home", icon: Flame },
  { to: "/browse", label: "Browse", icon: Compass },
  { to: "/airing", label: "Airing", icon: CalendarClock },
  { to: "/list", label: "My List", icon: Bookmark, auth: true },
];

type HeaderProfile = { avatar_url: string | null; display_name: string | null } | null;

export function SiteHeader() {
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const userId = user?.id ?? null;

  const { data: profile } = useQuery<HeaderProfile>({
    queryKey: ["header-profile", userId],
    enabled: !!userId,
    staleTime: 0,
    refetchOnWindowFocus: true,
    refetchOnMount: true,
    refetchInterval: 15000,
    queryFn: async () => {
      if (!userId) return null;
      const { data } = await supabase
        .from("profiles")
        .select("avatar_url, display_name")
        .eq("user_id", userId)
        .maybeSingle();
      return (data as HeaderProfile) ?? null;
    },
  });

  // Live-refresh avatar when the profile row changes in the DB.
  useEffect(() => {
    if (!userId) return;
    const channel = supabase
      .channel(`profile-header-${userId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "profiles", filter: `user_id=eq.${userId}` },
        () => qc.invalidateQueries({ queryKey: ["header-profile", userId] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, qc]);

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  }

  const avatarUrl = profile?.avatar_url ?? null;
  const initial = (profile?.display_name?.trim()?.[0] ?? user?.email?.[0] ?? "?").toUpperCase();

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/75 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid size-9 place-items-center rounded-lg bg-[var(--gradient-otaku)] shadow-[var(--neon-glow)]">
            <Sparkles className="size-5 text-white" />
          </div>
          <span className="text-base font-black tracking-tight sm:text-lg">
            OTAKU<span className="text-primary">VERSE</span>
          </span>
        </Link>

        <nav className="flex items-center gap-1">
          {navItems.map((item) => {
            if (item.auth && !isAuthenticated) return null;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-card hover:text-foreground data-[status=active]:bg-primary/15 data-[status=active]:text-primary"
                activeOptions={{ exact: item.to === "/" }}
              >
                <Icon className="size-4" />
                <span className="hidden sm:inline">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {isAuthenticated && user ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="rounded-full">
                {avatarUrl ? (
                  <span
                    className="size-8 rounded-full border border-border bg-muted bg-cover bg-center shadow-[var(--neon-glow)]"
                    style={{ backgroundImage: `url(${avatarUrl})` }}
                    aria-label="Profile avatar"
                  />
                ) : (
                  <span className="grid size-8 place-items-center rounded-full bg-[var(--gradient-otaku)] text-xs font-bold text-white shadow-[var(--neon-glow)]">
                    {initial}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="truncate text-xs text-muted-foreground">
                {profile?.display_name || user.email}
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate({ to: "/list" })}>
                <Bookmark className="mr-2 size-4" /> My List
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate({ to: "/settings" })}>
                <SettingsIcon className="mr-2 size-4" /> Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={signOut}>
                <LogOut className="mr-2 size-4" /> Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Button asChild size="sm" className="rounded-full bg-[var(--gradient-otaku)] text-white shadow-[var(--neon-glow)] hover:opacity-90">
            <Link to="/auth">
              <UserIcon className="mr-1.5 size-4" /> Sign in
            </Link>
          </Button>
        )}
      </div>
    </header>
  );
}
