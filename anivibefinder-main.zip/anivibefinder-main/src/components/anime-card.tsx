import { Link } from "@tanstack/react-router";
import { Star } from "lucide-react";
import type { AnimeCard as AnimeCardType } from "@/lib/anilist";
import { useBlur18, useCardDensity } from "@/hooks/use-prefs";
import { cn } from "@/lib/utils";

export function AnimeCard({ anime }: { anime: AnimeCardType }) {
  const density = useCardDensity();
  const blurAdult = useBlur18();
  const shouldBlur = blurAdult && anime.isAdult;

  if (density === "detailed") {
    return (
      <Link
        to="/anime/$id"
        params={{ id: String(anime.id) }}
        className="group flex items-center gap-4 rounded-xl border border-border/60 bg-card/60 p-3 transition-colors hover:border-primary/60 hover:shadow-[var(--neon-glow)]"
      >
        {anime.coverImage ? (
          <img
            src={anime.coverImage}
            alt={anime.title}
            loading="lazy"
            className={cn(
              "h-24 w-16 shrink-0 rounded object-cover transition-all",
              shouldBlur && "blur-lg group-hover:blur-0",
            )}
          />
        ) : (
          <div className="h-24 w-16 shrink-0 rounded bg-muted" />
        )}
        <div className="min-w-0 flex-1">
          <h3 className="line-clamp-1 font-bold">{anime.title}</h3>
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {anime.year && <span>{anime.year}</span>}
            {anime.format && <span>{anime.format.replace("_", " ")}</span>}
            {anime.episodes && <span>{anime.episodes} eps</span>}
            {anime.score != null && (
              <span className="flex items-center gap-1 text-primary">
                <Star className="size-3 fill-primary text-primary" /> {anime.score.toFixed(1)}
              </span>
            )}
            {anime.isAdult && (
              <span className="rounded bg-destructive/20 px-1.5 py-0.5 text-[10px] font-bold text-destructive">18+</span>
            )}
          </div>
          {anime.genres.length > 0 && (
            <p className="mt-1 line-clamp-1 text-xs text-muted-foreground/80">
              {anime.genres.slice(0, 4).join(" · ")}
            </p>
          )}
        </div>
      </Link>
    );
  }

  return (
    <Link
      to="/anime/$id"
      params={{ id: String(anime.id) }}
      className="group relative block aspect-[2/3] overflow-hidden rounded-xl border border-border/60 transition-all duration-300 hover:-translate-y-1 hover:border-primary/80 hover:shadow-[var(--neon-glow)]"
    >
      {anime.coverImage ? (
        <img
          src={anime.coverImage}
          alt={anime.title}
          loading="lazy"
          className={cn(
            "absolute inset-0 size-full object-cover transition-all duration-500 group-hover:scale-105",
            shouldBlur && "blur-xl group-hover:blur-0",
          )}
        />
      ) : (
        <div className="absolute inset-0 bg-card" />
      )}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black via-black/80 to-transparent p-3">
        <h3 className="line-clamp-2 text-sm font-bold text-white drop-shadow">{anime.title}</h3>
        <div className="mt-1 flex items-center justify-between text-[11px] text-white/85">
          <span className="font-semibold">{anime.year ?? "—"}</span>
          {anime.score != null && (
            <span className="flex items-center gap-1">
              <Star className="size-3 fill-primary text-primary" />
              {anime.score.toFixed(1)}
            </span>
          )}
        </div>
      </div>
      {anime.isAdult && (
        <span className="absolute left-2 top-2 rounded bg-destructive/90 px-1.5 py-0.5 text-[10px] font-bold text-white">18+</span>
      )}
    </Link>
  );
}
