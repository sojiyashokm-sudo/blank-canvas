import { Link } from "@tanstack/react-router";
import { Radio, Tv2, Clock, Loader2, CalendarDays, CircleCheck, CalendarClock, HelpCircle } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import {
  getSeasonAnime,
  getUnscheduledUpcoming,
  currentSeason,
  SEASONS,
  seasonYearRange,
  type SeasonEntry,
  type StreamingLink,
  type MediaSeason,
} from "@/lib/anilist";
import { useNow } from "@/hooks/use-now";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

type FilterTab = "airing" | "completed" | "upcoming" | "unscheduled";

const SITE_COLORS: Record<string, string> = {
  Crunchyroll: "#F47521", Netflix: "#E50914", Hulu: "#1CE783",
  Funimation: "#5A0CB5", HIDIVE: "#00BAE8", Hidive: "#00BAE8",
  "Amazon Prime Video": "#00A8E1", Amazon: "#00A8E1",
  "Disney Plus": "#0E47A1", "Disney+": "#0E47A1",
  YouTube: "#FF0000", Bilibili: "#00A1D6", Max: "#0046FF", "HBO Max": "#0046FF",
};

function formatCountdown(secondsLeft: number): string {
  if (secondsLeft <= 0) return "Airing now";
  const d = Math.floor(secondsLeft / 86400);
  const h = Math.floor((secondsLeft % 86400) / 3600);
  const m = Math.floor((secondsLeft % 3600) / 60);
  const s = secondsLeft % 60;
  if (d > 0) return `${d}d ${h}h ${m}m ${String(s).padStart(2, "0")}s`;
  if (h > 0) return `${h}h ${m}m ${String(s).padStart(2, "0")}s`;
  return `${m}m ${String(s).padStart(2, "0")}s`;
}

export function LiveSchedule() {
  const cur = currentSeason();
  const [season, setSeason] = useState<MediaSeason>(cur.season);
  const [year, setYear] = useState<number>(cur.year);
  const [tab, setTab] = useState<FilterTab>("airing");
  const now = useNow(1000);
  const years = useMemo(seasonYearRange, []);

  const seasonQuery = useInfiniteQuery({
    queryKey: ["season-schedule", season, year],
    queryFn: ({ pageParam }) => getSeasonAnime(season, year, pageParam, 50),
    initialPageParam: 1,
    getNextPageParam: (last, all) => (last.hasNextPage ? all.length + 1 : undefined),
    refetchInterval: 5 * 60_000,
    staleTime: 60_000,
  });

  const unscheduledQuery = useInfiniteQuery({
    queryKey: ["unscheduled-upcoming"],
    queryFn: ({ pageParam }) => getUnscheduledUpcoming(pageParam, 30),
    initialPageParam: 1,
    getNextPageParam: (last, all) => (last.hasNextPage ? all.length + 1 : undefined),
    enabled: tab === "unscheduled",
    staleTime: 5 * 60_000,
  });

  const seasonItems = seasonQuery.data?.pages.flatMap((p) => p.items) ?? [];
  const unscheduledItems = unscheduledQuery.data?.pages.flatMap((p) => p.items) ?? [];

  // Auto-fetch the entire season (cap ~500 titles / 10 pages) so counters and
  // the Airing/Completed/Upcoming tabs reflect the FULL season, not just the
  // first popular page.
  useEffect(() => {
    if (
      seasonQuery.hasNextPage &&
      !seasonQuery.isFetchingNextPage &&
      (seasonQuery.data?.pages.length ?? 0) < 10
    ) {
      seasonQuery.fetchNextPage();
    }
  }, [seasonQuery.data?.pages.length, seasonQuery.hasNextPage, seasonQuery.isFetchingNextPage, seasonQuery.fetchNextPage]);

  // Same for unscheduled tab when active.
  useEffect(() => {
    if (
      tab === "unscheduled" &&
      unscheduledQuery.hasNextPage &&
      !unscheduledQuery.isFetchingNextPage &&
      (unscheduledQuery.data?.pages.length ?? 0) < 5
    ) {
      unscheduledQuery.fetchNextPage();
    }
  }, [tab, unscheduledQuery.data?.pages.length, unscheduledQuery.hasNextPage, unscheduledQuery.isFetchingNextPage, unscheduledQuery.fetchNextPage]);

  const filtered = useMemo(() => {
    if (tab === "unscheduled") return unscheduledItems;
    return seasonItems.filter((e) => {
      if (tab === "airing") return e.status === "RELEASING";
      if (tab === "completed") return e.status === "FINISHED" || e.status === "CANCELLED";
      if (tab === "upcoming") return e.status === "NOT_YET_RELEASED" || e.status === "HIATUS";
      return true;
    });
  }, [seasonItems, unscheduledItems, tab]);

  const counts = useMemo(() => ({
    airing: seasonItems.filter((e) => e.status === "RELEASING").length,
    completed: seasonItems.filter((e) => e.status === "FINISHED" || e.status === "CANCELLED").length,
    upcoming: seasonItems.filter((e) => e.status === "NOT_YET_RELEASED" || e.status === "HIATUS").length,
  }), [seasonItems]);

  const activeQuery = tab === "unscheduled" ? unscheduledQuery : seasonQuery;

  return (
    <div className="space-y-6">
      {/* Header + season selector */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-primary">
            <Radio className="size-3.5 animate-pulse" /> Live · {season} {year}
          </div>
          <h2 className="mt-1 text-2xl font-black tracking-tight sm:text-3xl">Seasonal schedule</h2>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={season} onValueChange={(v) => setSeason(v as MediaSeason)}>
            <SelectTrigger className="w-32 rounded-full border-border bg-card/60 backdrop-blur"><SelectValue /></SelectTrigger>
            <SelectContent>
              {SEASONS.map((s) => <SelectItem key={s} value={s}>{s.charAt(0) + s.slice(1).toLowerCase()}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
            <SelectTrigger className="w-28 rounded-full border-border bg-card/60 backdrop-blur"><SelectValue /></SelectTrigger>
            <SelectContent className="max-h-72">
              {years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button
            size="sm" variant="outline"
            onClick={() => { setSeason(cur.season); setYear(cur.year); }}
            className="rounded-full"
          >
            This season
          </Button>
        </div>
      </div>

      {/* Filter tabs */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as FilterTab)}>
        <TabsList className="flex h-auto w-full flex-wrap gap-1 rounded-full border border-border bg-card/60 p-1 backdrop-blur sm:w-fit">
          <FilterTrigger value="airing" icon={Radio} count={counts.airing}>Airing Now</FilterTrigger>
          <FilterTrigger value="completed" icon={CircleCheck} count={counts.completed}>Completed</FilterTrigger>
          <FilterTrigger value="upcoming" icon={CalendarClock} count={counts.upcoming}>Upcoming / Leftovers</FilterTrigger>
          <FilterTrigger value="unscheduled" icon={HelpCircle}>Unscheduled (TBA)</FilterTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-6">
          <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
            <CalendarDays className="size-3.5" />
            {tab === "unscheduled"
              ? "Announced anime without a confirmed release date."
              : `${filtered.length} ${filtered.length === 1 ? "title" : "titles"} · ${season} ${year}`}
          </div>

          {activeQuery.isLoading ? (
            <div className="flex items-center justify-center py-20 text-muted-foreground">
              <Loader2 className="mr-2 size-5 animate-spin text-primary" /> Loading schedule…
            </div>
          ) : activeQuery.isError ? (
            <p className="rounded-xl border border-destructive/40 bg-destructive/10 p-6 text-center text-sm text-destructive">
              Couldn't reach the schedule feed. Try again shortly.
            </p>
          ) : filtered.length === 0 ? (
            <p className="rounded-xl border border-dashed border-border p-10 text-center text-muted-foreground">
              Nothing here for this filter.
            </p>
          ) : (
            <>
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {filtered.map((entry) => (
                  <ScheduleCard key={entry.media.id} entry={entry} now={now} />
                ))}
              </div>
              {activeQuery.hasNextPage && (
                <div className="mt-8 flex justify-center">
                  <Button
                    onClick={() => activeQuery.fetchNextPage()}
                    disabled={activeQuery.isFetchingNextPage}
                    className="rounded-full bg-[var(--gradient-otaku)] px-8 py-6 text-white shadow-[var(--neon-glow)]"
                  >
                    {activeQuery.isFetchingNextPage
                      ? <><Loader2 className="mr-2 size-4 animate-spin" /> Loading…</>
                      : "Load more"}
                  </Button>
                </div>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function FilterTrigger({
  value, icon: Icon, count, children,
}: { value: string; icon: React.ComponentType<{ className?: string }>; count?: number; children: React.ReactNode }) {
  return (
    <TabsTrigger
      value={value}
      className="gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium data-[state=active]:bg-[var(--gradient-otaku)] data-[state=active]:text-white data-[state=active]:shadow-[var(--neon-glow)] sm:text-sm"
    >
      <Icon className="size-3.5" /> {children}
      {count != null && <span className="ml-1 rounded-full bg-background/40 px-1.5 text-[10px] tabular-nums">{count}</span>}
    </TabsTrigger>
  );
}

function ScheduleCard({ entry, now }: { entry: SeasonEntry; now: number }) {
  const next = entry.nextAiringEpisode;
  const secondsLeft = next ? next.airingAt - Math.floor(now / 1000) : null;
  const startStr = entry.startDate?.year
    ? [entry.startDate.year, entry.startDate.month, entry.startDate.day].filter(Boolean).join("-")
    : "TBA";

  const statusBadge = (() => {
    switch (entry.status) {
      case "RELEASING": return { label: "Airing", cls: "bg-primary/20 text-primary" };
      case "FINISHED": return { label: "Finished", cls: "bg-emerald-500/20 text-emerald-300" };
      case "NOT_YET_RELEASED": return { label: "Upcoming", cls: "bg-amber-500/20 text-amber-300" };
      case "HIATUS": return { label: "Hiatus", cls: "bg-orange-500/20 text-orange-300" };
      case "CANCELLED": return { label: "Cancelled", cls: "bg-destructive/20 text-destructive" };
      default: return null;
    }
  })();

  return (
    <Link
      to="/anime/$id"
      params={{ id: String(entry.media.id) }}
      className="group relative flex overflow-hidden rounded-xl border border-border/60 bg-card/40 backdrop-blur transition-all hover:border-primary/60 hover:shadow-[var(--neon-glow)]"
    >
      {entry.bannerImage && (
        <div className="pointer-events-none absolute inset-0 opacity-10 transition-opacity group-hover:opacity-20">
          <img src={entry.bannerImage} alt="" className="size-full object-cover" />
        </div>
      )}

      <div className="relative shrink-0">
        <img
          src={entry.media.coverImage}
          alt=""
          className="h-full max-h-48 w-28 object-cover sm:w-32"
          loading="lazy"
        />
      </div>

      <div className="relative flex min-w-0 flex-1 flex-col gap-1.5 p-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="line-clamp-2 text-sm font-bold leading-tight">{entry.media.title}</h3>
          {statusBadge && (
            <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider", statusBadge.cls)}>
              {statusBadge.label}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <Tv2 className="size-3" />
          <span className="truncate">{entry.studios[0] ?? "Unknown studio"}</span>
          {entry.media.format && <span>· {entry.media.format}</span>}
        </div>

        {next && secondsLeft != null && secondsLeft > -3600 ? (
          <div className="flex items-center gap-1.5 rounded-md bg-primary/10 px-2 py-1 text-xs font-bold text-primary">
            <Clock className="size-3.5" />
            <span className="tabular-nums">
              Ep {next.episode} · {formatCountdown(secondsLeft)}
            </span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <CalendarDays className="size-3" />
            <span>{startStr}{entry.media.episodes ? ` · ${entry.media.episodes} eps` : ""}</span>
          </div>
        )}

        {entry.description && (
          <p className="line-clamp-2 text-[11px] text-muted-foreground">{entry.description}</p>
        )}

        {entry.streaming.length > 0 && (
          <div className="mt-auto flex flex-wrap gap-1 pt-1">
            {entry.streaming.slice(0, 4).map((l) => <StreamingBadge key={l.id} link={l} />)}
          </div>
        )}
      </div>
    </Link>
  );
}

function StreamingBadge({ link }: { link: StreamingLink }) {
  const color = SITE_COLORS[link.site] ?? link.color ?? "#7c3aed";
  return (
    <span
      className="rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white"
      style={{ backgroundColor: color }}
      title={link.site}
    >
      {link.site}
    </span>
  );
}
