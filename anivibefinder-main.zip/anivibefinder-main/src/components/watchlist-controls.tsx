import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Bookmark, Check, Minus, Plus, Star, Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import {
  upsertWatchlistEntry,
  removeWatchlistEntry,
  getWatchlistEntry,
} from "@/lib/watchlist.functions";
import type { AnimeDetail } from "@/lib/anilist";

const STATUS_OPTIONS = [
  { value: "watching", label: "Watching" },
  { value: "completed", label: "Completed" },
  { value: "planning", label: "Plan to Watch" },
  { value: "paused", label: "On Hold" },
  { value: "dropped", label: "Dropped" },
] as const;
type Status = (typeof STATUS_OPTIONS)[number]["value"];

export function WatchlistControls({ anime }: { anime: AnimeDetail }) {
  const { isAuthenticated } = useAuth();
  const qc = useQueryClient();
  const getEntry = useServerFn(getWatchlistEntry);
  const upsert = useServerFn(upsertWatchlistEntry);
  const remove = useServerFn(removeWatchlistEntry);

  const entryQuery = useQuery({
    queryKey: ["watchlist-entry", anime.id],
    queryFn: () => getEntry({ data: { anilist_id: anime.id } }),
    enabled: isAuthenticated,
  });

  const [status, setStatus] = useState<Status>("planning");
  const [progress, setProgress] = useState(0);
  const [score, setScore] = useState<number | null>(null);

  useEffect(() => {
    if (entryQuery.data) {
      setStatus(entryQuery.data.status as Status);
      setProgress(entryQuery.data.progress);
      setScore(entryQuery.data.score);
    }
  }, [entryQuery.data]);

  const save = useMutation({
    mutationFn: (payload: { status: Status; progress: number; score: number | null }) =>
      upsert({
        data: {
          anilist_id: anime.id,
          status: payload.status,
          progress: payload.progress,
          score: payload.score,
          title: anime.title,
          cover_url: anime.coverImage,
          total_episodes: anime.episodes,
          format: anime.format,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["watchlist-entry", anime.id] });
      qc.invalidateQueries({ queryKey: ["my-watchlist"] });
      toast.success("Saved to your list");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: () => remove({ data: { anilist_id: anime.id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["watchlist-entry", anime.id] });
      qc.invalidateQueries({ queryKey: ["my-watchlist"] });
      setStatus("planning"); setProgress(0); setScore(null);
      toast.success("Removed from your list");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-card/60 p-4">
        <p className="text-sm text-muted-foreground">
          <Link to="/auth" className="font-bold text-primary hover:underline">Sign in</Link> to add this to your list and track your progress.
        </p>
      </div>
    );
  }

  const hasEntry = !!entryQuery.data;
  const total = anime.episodes ?? 9999;

  function update(next: Partial<{ status: Status; progress: number; score: number | null }>) {
    const merged = {
      status: next.status ?? status,
      progress: next.progress ?? progress,
      score: next.score !== undefined ? next.score : score,
    };
    // auto-complete when finishing the last episode
    if (anime.episodes && merged.progress >= anime.episodes && merged.status === "watching") {
      merged.status = "completed";
    }
    setStatus(merged.status); setProgress(merged.progress); setScore(merged.score);
    save.mutate(merged);
  }

  return (
    <div className="space-y-3 rounded-xl border border-primary/30 bg-primary/5 p-4 shadow-[var(--neon-glow)]">
      <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-primary">
        <Bookmark className="size-4" />
        {hasEntry ? "In your list" : "Add to your list"}
      </div>

      <Select value={status} onValueChange={(v) => update({ status: v as Status })}>
        <SelectTrigger className="bg-card">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {STATUS_OPTIONS.map((s) => (
            <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      <div className="flex items-center justify-between gap-2">
        <span className="text-xs uppercase tracking-wider text-muted-foreground">Episode</span>
        <div className="flex items-center gap-1">
          <Button size="icon" variant="outline" className="size-7" onClick={() => update({ progress: Math.max(0, progress - 1) })}>
            <Minus className="size-3" />
          </Button>
          <span className="min-w-16 text-center font-mono text-sm font-bold">
            {progress} / {anime.episodes ?? "?"}
          </span>
          <Button size="icon" variant="outline" className="size-7" onClick={() => update({ progress: Math.min(total, progress + 1) })}>
            <Plus className="size-3" />
          </Button>
        </div>
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">Your score</span>
          {score != null && (
            <button onClick={() => update({ score: null })} className="text-xs text-muted-foreground hover:text-foreground">clear</button>
          )}
        </div>
        <div className="flex flex-wrap gap-1">
          {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
            <button
              key={n}
              onClick={() => update({ score: n })}
              className={`grid size-7 place-items-center rounded-md text-xs font-bold transition-colors ${
                score && n <= score
                  ? "bg-[var(--gradient-otaku)] text-white shadow-[var(--neon-glow)]"
                  : "bg-card text-muted-foreground hover:bg-card/80"
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </div>

      {hasEntry && (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => del.mutate()}
          disabled={del.isPending}
          className="w-full text-destructive hover:bg-destructive/10 hover:text-destructive"
        >
          {del.isPending ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Trash2 className="mr-2 size-4" />}
          Remove from list
        </Button>
      )}

      {save.isPending && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="size-3 animate-spin" /> Saving…
        </div>
      )}
      {hasEntry && !save.isPending && (
        <div className="flex items-center gap-1.5 text-xs text-primary">
          <Check className="size-3" /> Synced
        </div>
      )}

      {score != null && (
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Star className="size-3 fill-primary text-primary" /> Your rating: <span className="font-bold text-foreground">{score}/10</span>
        </div>
      )}
    </div>
  );
}
