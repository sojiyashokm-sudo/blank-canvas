import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Plus, PlayCircle, Loader2, Check, PauseCircle } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import { getMyWatchlist, upsertWatchlistEntry } from "@/lib/watchlist.functions";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type WatchStatus = "watching" | "completed" | "planning" | "paused" | "dropped";

export function ContinueWatching() {
  const { isAuthenticated } = useAuth();
  const qc = useQueryClient();
  const fetchList = useServerFn(getMyWatchlist);
  const upsert = useServerFn(upsertWatchlistEntry);

  const q = useQuery({
    queryKey: ["my-watchlist"],
    queryFn: () => fetchList(),
    enabled: isAuthenticated,
  });

  type Row = NonNullable<typeof q.data>[number];

  const setProgress = useMutation({
    mutationFn: ({ row, progress }: { row: Row; progress: number }) =>
      upsert({
        data: {
          anilist_id: row.anilist_id,
          status:
            row.total_episodes && progress >= row.total_episodes
              ? "completed"
              : "watching",
          progress,
          score: row.score,
          title: row.title,
          cover_url: row.cover_url,
          total_episodes: row.total_episodes,
          format: row.format,
        },
      }),
    onMutate: async ({ row, progress }) => {
      await qc.cancelQueries({ queryKey: ["my-watchlist"] });
      const prev = qc.getQueryData<Row[]>(["my-watchlist"]);
      qc.setQueryData<Row[]>(["my-watchlist"], (old) =>
        (old ?? []).map((r) =>
          r.anilist_id === row.anilist_id ? { ...r, progress } : r,
        ),
      );
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(["my-watchlist"], ctx.prev);
      toast.error("Couldn't update progress");
    },
    onSuccess: (_d, { row, progress }) => {
      qc.invalidateQueries({ queryKey: ["watchlist-entry", row.anilist_id] });
      toast.success(`Progress set to Ep ${progress}`);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["my-watchlist"] }),
  });

  const setStatus = useMutation({
    mutationFn: ({ row, status }: { row: Row; status: WatchStatus }) =>
      upsert({
        data: {
          anilist_id: row.anilist_id,
          status,
          progress:
            status === "completed" && row.total_episodes
              ? row.total_episodes
              : row.progress,
          score: row.score,
          title: row.title,
          cover_url: row.cover_url,
          total_episodes: row.total_episodes,
          format: row.format,
        },
      }),
    onMutate: async ({ row, status }) => {
      await qc.cancelQueries({ queryKey: ["my-watchlist"] });
      const prev = qc.getQueryData<Row[]>(["my-watchlist"]);
      qc.setQueryData<Row[]>(["my-watchlist"], (old) =>
        (old ?? []).map((r) =>
          r.anilist_id === row.anilist_id ? { ...r, status } : r,
        ),
      );
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(["my-watchlist"], ctx.prev);
      toast.error("Couldn't update status");
    },
    onSuccess: (_d, { status }) => {
      toast.success(
        status === "completed" ? "Marked as completed" : "Moved to on hold",
      );
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["my-watchlist"] }),
  });

  if (!isAuthenticated) return null;

  const watching = (q.data ?? []).filter((r) => r.status === "watching");
  if (q.isLoading || watching.length === 0) return null;

  return (
    <section className="mb-8">
      <div className="mb-3 flex items-center gap-2">
        <PlayCircle className="size-4 text-primary" />
        <h2 className="text-sm font-bold uppercase tracking-widest text-primary">
          Continue watching
        </h2>
      </div>
      <div className="-mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {watching.map((row) => {
          const isBumping =
            setProgress.isPending &&
            setProgress.variables?.row.anilist_id === row.anilist_id;
          return (
            <SwipeCard
              key={row.anilist_id}
              row={row}
              isBumping={isBumping}
              onIncrement={() =>
                setProgress.mutate({ row, progress: row.progress + 1 })
              }
              onSetProgress={(progress) => setProgress.mutate({ row, progress })}
              onComplete={() => setStatus.mutate({ row, status: "completed" })}
              onHold={() => setStatus.mutate({ row, status: "paused" })}
            />
          );
        })}
      </div>
    </section>
  );
}

function SwipeCard({
  row,
  isBumping,
  onIncrement,
  onSetProgress,
  onComplete,
  onHold,
}: {
  row: {
    anilist_id: number;
    title: string;
    cover_url: string | null;
    progress: number;
    total_episodes: number | null;
  };
  isBumping: boolean;
  onIncrement: () => void;
  onSetProgress: (n: number) => void;
  onComplete: () => void;
  onHold: () => void;
}) {
  const [dx, setDx] = useState(0);
  const [glow, setGlow] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const start = useRef<{ x: number; y: number; id: number } | null>(null);
  const swiping = useRef(false);
  const pct = row.total_episodes
    ? Math.min(100, (row.progress / row.total_episodes) * 100)
    : 0;

  const THRESHOLD = 70;
  const MAX = 120;

  const flashGlow = () => {
    setGlow(true);
    window.setTimeout(() => setGlow(false), 600);
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if (e.pointerType === "mouse") return;
    start.current = { x: e.clientX, y: e.clientY, id: e.pointerId };
    swiping.current = false;
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!start.current || start.current.id !== e.pointerId) return;
    const dX = e.clientX - start.current.x;
    const dY = e.clientY - start.current.y;
    if (!swiping.current) {
      if (Math.abs(dX) < 10) return;
      if (Math.abs(dY) > Math.abs(dX)) {
        start.current = null;
        return;
      }
      swiping.current = true;
      (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    }
    setDx(Math.max(-MAX, Math.min(MAX, dX)));
  };
  const finish = (e: React.PointerEvent) => {
    if (!start.current) return;
    const wasSwiping = swiping.current;
    const finalDx = dx;
    start.current = null;
    swiping.current = false;
    setDx(0);
    if (!wasSwiping) return;
    e.preventDefault();
    e.stopPropagation();
    if (finalDx >= THRESHOLD) {
      flashGlow();
      onIncrement();
    } else if (finalDx <= -THRESHOLD) {
      setMenuOpen(true);
    }
  };
  const swipeActive = Math.abs(dx) > 8;

  const revealRight = dx > 0;
  const revealLeft = dx < 0;

  return (
    <div className="relative w-40 flex-shrink-0 snap-start">
      {/* Left action reveal (swipe right -> +1) */}
      <div
        className={cn(
          "pointer-events-none absolute inset-y-0 left-0 flex w-24 items-center justify-start rounded-xl bg-gradient-to-r from-primary/70 to-transparent pl-3 transition-opacity",
          revealRight ? "opacity-100" : "opacity-0",
        )}
      >
        <Plus className="size-6 text-white drop-shadow" strokeWidth={3} />
      </div>
      {/* Right action reveal (swipe left -> menu) */}
      <div
        className={cn(
          "pointer-events-none absolute inset-y-0 right-0 flex w-24 items-center justify-end rounded-xl bg-gradient-to-l from-accent/70 to-transparent pr-3 transition-opacity",
          revealLeft ? "opacity-100" : "opacity-0",
        )}
      >
        <span className="text-[10px] font-bold uppercase tracking-widest text-white">
          Actions
        </span>
      </div>

      <div
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={finish}
        onPointerCancel={finish}
        onClickCapture={(e) => {
          if (swipeActive) {
            e.preventDefault();
            e.stopPropagation();
          }
        }}
        style={{
          transform: `translateX(${dx}px)`,
          transition: swipeActive ? "none" : "transform 250ms ease",
          touchAction: "pan-y",
        }}
        className={cn(
          "group relative overflow-hidden rounded-xl border border-border/60 bg-card transition-colors hover:border-primary/60",
          glow && "border-foreground/70 animate-in fade-in",
        )}
      >
        <Link
          to="/anime/$id"
          params={{ id: String(row.anilist_id) }}
          className="block"
          draggable={false}
        >
          <div className="relative aspect-[2/3] overflow-hidden">
            {row.cover_url ? (
              <img
                src={row.cover_url}
                alt={row.title}
                loading="lazy"
                draggable={false}
                className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            ) : (
              <div className="size-full bg-muted" />
            )}
            {glow && (
              <div className="pointer-events-none absolute inset-0 animate-in fade-in bg-white/15" />
            )}
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-2 pt-6">
              <EpisodeEditor row={row} onSave={onSetProgress} isPending={isBumping} />
              <div className="mt-1 h-1 overflow-hidden rounded-full bg-white/20">
                <div
                  className="h-full bg-[var(--gradient-otaku)]"
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          </div>
          <div className="p-2">
            <h3 className="line-clamp-2 text-xs font-bold">{row.title}</h3>
          </div>
        </Link>

        <Popover open={menuOpen} onOpenChange={setMenuOpen}>
          <PopoverTrigger asChild>
            <span className="absolute right-2 bottom-14 size-0" aria-hidden />
          </PopoverTrigger>
          <PopoverContent
            className="w-48 p-2"
            align="end"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-1 px-2 text-[10px] font-bold uppercase tracking-widest text-primary">
              Quick actions
            </div>
            <button
              type="button"
              onClick={() => {
                onComplete();
                setMenuOpen(false);
              }}
              className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm hover:bg-primary/10"
            >
              <Check className="size-4 text-primary" /> Mark completed
            </button>
            <button
              type="button"
              onClick={() => {
                onHold();
                setMenuOpen(false);
              }}
              className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm hover:bg-primary/10"
            >
              <PauseCircle className="size-4 text-primary" /> On hold
            </button>
          </PopoverContent>
        </Popover>

        <button
          type="button"
          aria-label={`Log episode ${row.progress + 1}`}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            flashGlow();
            onIncrement();
          }}
          disabled={isBumping}
          className="absolute right-2 top-2 grid size-8 place-items-center rounded-full bg-[var(--gradient-otaku)] text-white shadow-[var(--neon-glow)] ring-2 ring-background transition-transform hover:scale-110 active:scale-95 disabled:opacity-70"
        >
          {isBumping ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Plus className="size-4" strokeWidth={3} />
          )}
        </button>
      </div>
    </div>
  );
}

function EpisodeEditor({
  row,
  onSave,
  isPending,
}: {
  row: { progress: number; total_episodes: number | null };
  onSave: (progress: number) => void;
  isPending: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(String(row.progress));
  const max = row.total_episodes ?? 9999;

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (o) setValue(String(row.progress));
      }}
    >
      <PopoverTrigger asChild>
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
          className="text-left text-[11px] font-bold text-white/95 underline decoration-primary/60 decoration-dotted underline-offset-2 hover:text-primary"
        >
          Ep {row.progress}
          {row.total_episodes ? ` / ${row.total_episodes}` : ""}
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-56 p-3"
        align="start"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
        }}
      >
        <div className="mb-2 text-xs font-bold uppercase tracking-wider text-primary">
          Set episode
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const n = Math.max(0, Math.min(max, Number(value) || 0));
            onSave(n);
            setOpen(false);
          }}
          className="flex items-center gap-2"
        >
          <Input
            type="number"
            min={0}
            max={max}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            autoFocus
            className="h-8"
          />
          <Button type="submit" size="sm" disabled={isPending} className="h-8">
            {isPending ? <Loader2 className="size-3 animate-spin" /> : "Save"}
          </Button>
        </form>
        {row.total_episodes && (
          <div className="mt-2 text-[10px] text-muted-foreground">
            Max: {row.total_episodes}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
