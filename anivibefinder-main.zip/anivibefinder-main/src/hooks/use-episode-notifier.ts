import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/hooks/use-auth";
import { getMyWatchlist } from "@/lib/watchlist.functions";
import { getAiringInfoForIds } from "@/lib/anilist";
import {
  fireEpisodeNotification,
  isEnabled,
  lastNotifiedEpisode,
  markNotified,
  notificationsSupported,
  NOTIF_ENABLED_KEY,
} from "@/lib/notifications";

const POLL_MS = 5 * 60 * 1000; // check every 5 minutes while the tab is open

/**
 * Foreground poller: while the app/tab is open and the user has enabled
 * notifications, checks AniList for airing progress on their "watching" list
 * and fires a native Notification when a new episode has aired.
 */
export function useEpisodeNotifier() {
  const { isAuthenticated } = useAuth();
  const fetchList = useServerFn(getMyWatchlist);
  const enabledFlag = useEnabledFlag();

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!isAuthenticated) return;
    if (!notificationsSupported()) return;

    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    async function tick() {
      if (cancelled) return;
      try {
        if (!isEnabled() || Notification.permission !== "granted") return;
        const rows = await fetchList();
        const watching = rows.filter((r) => r.status === "watching");
        if (watching.length === 0) return;
        const infos = await getAiringInfoForIds(watching.map((r) => r.anilist_id));
        const nowSec = Math.floor(Date.now() / 1000);
        for (const info of infos) {
          const next = info.nextAiringEpisode;
          const airedEp = next
            ? next.airingAt <= nowSec
              ? next.episode
              : next.episode - 1
            : null;
          if (!airedEp || airedEp <= 0) continue;
          const row = watching.find((r) => r.anilist_id === info.id);
          if (!row) continue;
          const seen = lastNotifiedEpisode(info.id);
          const floor = Math.max(seen, row.progress);
          if (airedEp > floor) {
            fireEpisodeNotification({
              anilistId: info.id,
              title: info.title || row.title,
              episode: airedEp,
              coverImage: info.coverImage || row.cover_url || undefined,
            });
            markNotified(info.id, airedEp);
          }
        }
      } catch (err) {
        console.warn("[episode-notifier] check failed", err);
      } finally {
        if (!cancelled) timer = setTimeout(tick, POLL_MS);
      }
    }

    tick();

    const onVisible = () => {
      if (document.visibilityState === "visible") tick();
    };
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [isAuthenticated, enabledFlag, fetchList]);
}

/** Re-renders when the enabled flag changes in localStorage (same or other tab). */
function useEnabledFlag() {
  const [v, set] = useState<string | null>(() =>
    typeof window !== "undefined" ? localStorage.getItem(NOTIF_ENABLED_KEY) : null,
  );
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === NOTIF_ENABLED_KEY) set(localStorage.getItem(NOTIF_ENABLED_KEY));
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);
  return v;
}
