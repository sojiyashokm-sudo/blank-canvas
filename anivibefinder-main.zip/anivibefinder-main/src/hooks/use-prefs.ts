import { useEffect, useState } from "react";

export const LANDING_KEY = "default_landing_page";
export const DENSITY_KEY = "otakuverse_card_density";
export const BLUR18_KEY = "otakuverse_blur_18";
export const NOTIF_KEY = "otakuverse_notifications_enabled";

export type Density = "compact" | "detailed";
export type Landing = "home" | "browse" | "list";

// Map landing pref to actual internal route path.
export const LANDING_ROUTES: Record<Landing, string> = {
  home: "/",
  browse: "/browse",
  list: "/list",
};

function read(key: string, fallback: string): string {
  if (typeof window === "undefined") return fallback;
  return localStorage.getItem(key) ?? fallback;
}

export function writePref(key: string, value: string) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, value);
  window.dispatchEvent(new CustomEvent("otakuverse:prefs", { detail: { key, value } }));
}

function usePref(key: string, fallback: string): string {
  const [value, setValue] = useState(fallback);
  useEffect(() => {
    setValue(read(key, fallback));
    const onStorage = (e: StorageEvent) => {
      if (e.key === key) setValue(e.newValue ?? fallback);
    };
    const onCustom = (e: Event) => {
      const detail = (e as CustomEvent<{ key: string; value: string }>).detail;
      if (detail?.key === key) setValue(detail.value);
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener("otakuverse:prefs", onCustom as EventListener);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("otakuverse:prefs", onCustom as EventListener);
    };
  }, [key, fallback]);
  return value;
}

export function useCardDensity(): Density {
  const v = usePref(DENSITY_KEY, "compact");
  return v === "detailed" ? "detailed" : "compact";
}

export function useBlur18(): boolean {
  return usePref(BLUR18_KEY, "true") === "true";
}

export function useLandingPref(): Landing {
  const v = usePref(LANDING_KEY, "home");
  return v === "browse" || v === "list" ? v : "home";
}

export function readLandingPref(): Landing {
  if (typeof window === "undefined") return "home";
  const v = localStorage.getItem(LANDING_KEY);
  return v === "browse" || v === "list" ? v : "home";
}
