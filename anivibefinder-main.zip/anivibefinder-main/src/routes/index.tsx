import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import { Search, Sparkles, Flame, Gem, Loader2, Compass, CalendarClock, Radio, ArrowUpDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SiteHeader } from "@/components/site-header";
import { AnimeCard } from "@/components/anime-card";
import { useCardDensity, readLandingPref, LANDING_ROUTES } from "@/hooks/use-prefs";
import { LiveSchedule } from "@/components/live-schedule";
import { ContinueWatching } from "@/components/continue-watching";
import { browse, type MediaSort } from "@/lib/anilist";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OtakuVerse — Track every anime you watch" },
      { name: "description", content: "Search the entire AniList catalog, track your watchlist, rate episodes, and discover trending & airing anime. Free, no ads." },
      { property: "og:title", content: "OtakuVerse — Track every anime you watch" },
      { property: "og:description", content: "Watchlist, episode tracking, ratings, trailers, airing schedule, and smart recommendations." },
    ],
  }),
  component: Index,
});

const SUGGESTIONS = ["dark fantasy", "cozy slice of life", "mecha war", "isekai", "romance comedy", "psychological thriller"];

function Index() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [submitted, setSubmitted] = useState("");

  // Default landing page redirect: honor user preference on root visit.
  useEffect(() => {
    const pref = readLandingPref();
    if (pref !== "home") {
      const target = LANDING_ROUTES[pref];
      if (target && target !== "/") {
        navigate({ to: target, replace: true });
      }
    }
  }, [navigate]);


  const trending = useInfiniteQuery({
    queryKey: ["home-trending"],
    queryFn: ({ pageParam }) => browse({ sort: "TRENDING_DESC" }, pageParam, 24),
    initialPageParam: 1,
    getNextPageParam: (last, all) => (last.hasNextPage ? all.length + 1 : undefined),
  });

  // Hidden Gems — sub-sort + reverse toggle. Excludes mainstream hits via
  // AniList `popularity_lesser` (equivalent to MAL members < ~100k), so blockbusters
  // like Frieren, Attack on Titan, and Fullmetal Alchemist are filtered out.
  type GemsSort = "rating" | "recent" | "trending";
  const [gemsSort, setGemsSort] = useState<GemsSort>("rating");
  const [gemsReversed, setGemsReversed] = useState(false);

  const gemsSortValue: MediaSort = (() => {
    if (gemsSort === "rating") return gemsReversed ? "SCORE" : "SCORE_DESC";
    if (gemsSort === "recent") return gemsReversed ? "START_DATE" : "START_DATE_DESC";
    return gemsReversed ? "TRENDING" : "TRENDING_DESC";
  })();

  const gems = useInfiniteQuery({
    queryKey: ["home-gems", gemsSortValue],
    queryFn: ({ pageParam }) =>
      browse(
        {
          sort: gemsSortValue,
          popularityLesser: 100000,
          // Keep "Top Rated" meaningful (>= 6.5). Reverse mode strips this to
          // surface the absolute worst obscure experimental flops.
          averageScoreGreater: gemsSort === "rating" && !gemsReversed ? 65 : undefined,
        },
        pageParam,
        24,
      ),
    initialPageParam: 1,
    getNextPageParam: (last, all) => (last.hasNextPage ? all.length + 1 : undefined),
  });

  const smart = useInfiniteQuery({
    queryKey: ["home-search", submitted],
    queryFn: ({ pageParam }) => browse({ search: submitted, sort: "POPULARITY_DESC" }, pageParam, 24),
    initialPageParam: 1,
    getNextPageParam: (last, all) => (last.hasNextPage ? all.length + 1 : undefined),
    enabled: submitted.length > 0,
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-40 left-1/2 size-[600px] -translate-x-1/2 rounded-full bg-primary/15 blur-[140px]" />
        <div className="absolute bottom-0 right-0 size-[500px] rounded-full bg-accent/15 blur-[140px]" />
      </div>

      <SiteHeader />

      <main className="mx-auto max-w-7xl px-4 py-10">
        <section className="mb-10 text-center">
          <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary">
            <Sparkles className="size-3.5" /> Powered by AniList
          </div>
          <h1 className="mt-4 text-4xl font-black tracking-tight sm:text-5xl md:text-6xl">
            Find your next <span className="bg-[var(--gradient-otaku)] bg-clip-text text-transparent">obsession</span>
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-sm text-muted-foreground sm:text-base">
            Search by vibe, track your watchlist, rate episodes, follow the airing schedule — everything AniSync does, with a clean, minimalist design.
          </p>

          <form
            onSubmit={(e) => { e.preventDefault(); setSubmitted(search.trim()); }}
            className="mx-auto mt-6 flex max-w-2xl items-center gap-2 rounded-full border border-border bg-card/60 p-1.5 shadow-[var(--neon-glow)] backdrop-blur"
          >
            <Search className="ml-3 size-4 text-primary" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="A vibe, plot, or title… 'dark fantasy revenge', 'cozy magic'"
              className="border-0 bg-transparent text-base focus-visible:ring-0"
            />
            <Button type="submit" className="rounded-full bg-[var(--gradient-otaku)] text-white">Search</Button>
          </form>

          <div className="mt-3 flex flex-wrap justify-center gap-1.5">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => { setSearch(s); setSubmitted(s); }}
                className="rounded-full border border-border bg-card/40 px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
              >
                {s}
              </button>
            ))}
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <Button asChild variant="outline" className="rounded-full">
              <Link to="/browse"><Compass className="mr-1.5 size-4" /> Browse all</Link>
            </Button>
            <Button asChild variant="outline" className="rounded-full">
              <Link to="/airing"><CalendarClock className="mr-1.5 size-4" /> What's airing</Link>
            </Button>
          </div>
        </section>

        <ContinueWatching />

        <Tabs defaultValue={submitted ? "smart" : "trending"} className="w-full">
          <TabsList className="mx-auto flex h-auto w-fit flex-wrap gap-1 rounded-full border border-border bg-card/60 p-1 backdrop-blur">
            <TabTrigger value="trending" icon={Flame}>Trending</TabTrigger>
            <TabTrigger value="gems" icon={Gem}>Hidden Gems</TabTrigger>
            <TabTrigger value="smart" icon={Sparkles}>Smart Picks</TabTrigger>
            <TabTrigger value="schedule" icon={Radio}>Live Schedule</TabTrigger>
          </TabsList>

          <TabsContent value="trending" className="mt-6">
            <ResultsGrid query={trending} emptyMsg="No trending anime." />
          </TabsContent>
          <TabsContent value="gems" className="mt-6 animate-in fade-in-50 duration-300">
            <GemsSubSort
              sort={gemsSort}
              reversed={gemsReversed}
              onSortChange={setGemsSort}
              onToggleReverse={() => setGemsReversed((r) => !r)}
            />
            <ResultsGrid query={gems} emptyMsg="No gems found." />
          </TabsContent>
          <TabsContent value="smart" className="mt-6">
            {!submitted ? (
              <p className="rounded-xl border border-dashed border-border p-10 text-center text-muted-foreground">
                Type a vibe above to get smart picks across every anime on AniList.
              </p>
            ) : (
              <ResultsGrid query={smart} emptyMsg="Nothing matched that vibe." />
            )}
          </TabsContent>
          <TabsContent value="schedule" className="mt-6 animate-in fade-in-50 duration-300">
            <div className="mb-4 flex justify-end">
              <Button asChild variant="outline" size="sm" className="rounded-full">
                <Link to="/schedule">Open full page →</Link>
              </Button>
            </div>
            <LiveSchedule />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t border-border/60 py-6 text-center text-xs text-muted-foreground">
        Data by AniList GraphQL · Built with Lovable
      </footer>
    </div>
  );
}

function TabTrigger({ value, icon: Icon, children }: { value: string; icon: React.ComponentType<{ className?: string }>; children: React.ReactNode }) {
  return (
    <TabsTrigger
      value={value}
      className="gap-1.5 rounded-full px-4 py-1.5 text-sm font-medium data-[state=active]:bg-[var(--gradient-otaku)] data-[state=active]:text-white data-[state=active]:shadow-[var(--neon-glow)]"
    >
      <Icon className="size-4" /> {children}
    </TabsTrigger>
  );
}

type InfiniteQuery = ReturnType<typeof useInfiniteQuery<Awaited<ReturnType<typeof browse>>>>;

function ResultsGrid({ query, emptyMsg }: { query: InfiniteQuery; emptyMsg: string }) {
  const density = useCardDensity();
  if (query.isLoading) {
    return (
      <div className="flex items-center justify-center py-20 text-muted-foreground">
        <Loader2 className="mr-2 size-5 animate-spin text-primary" /> Loading…
      </div>
    );
  }
  if (query.isError) {
    return <p className="rounded-xl border border-destructive/40 bg-destructive/10 p-6 text-center text-sm text-destructive">Couldn't reach AniList. Try again.</p>;
  }
  const items = query.data?.pages.flatMap((p) => p.items) ?? [];
  if (items.length === 0) {
    return <p className="rounded-xl border border-dashed border-border p-10 text-center text-muted-foreground">{emptyMsg}</p>;
  }
  return (
    <>
      <div className={density === "detailed" ? "flex flex-col gap-2" : "grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6"}>
        {items.map((a) => <AnimeCard key={a.id} anime={a} />)}
      </div>
      {query.hasNextPage && (
        <div className="mt-8 flex justify-center">
          <Button
            onClick={() => query.fetchNextPage()}
            disabled={query.isFetchingNextPage}
            className="rounded-full bg-[var(--gradient-otaku)] px-8 py-6 text-white shadow-[var(--neon-glow)]"
          >
            {query.isFetchingNextPage ? <><Loader2 className="mr-2 size-4 animate-spin" /> Loading…</> : "Load more anime"}
          </Button>
        </div>
      )}
    </>
  );
}

type GemsSortKey = "rating" | "recent" | "trending";

const GEMS_SORTS: { key: GemsSortKey; label: string; normal: string; reversed: string }[] = [
  { key: "rating", label: "Top Rated", normal: "Highest score", reversed: "Lowest score" },
  { key: "recent", label: "Recent", normal: "Newest first", reversed: "Oldest first" },
  { key: "trending", label: "Trending", normal: "High hype", reversed: "Low hype" },
];

function GemsSubSort({
  sort,
  reversed,
  onSortChange,
  onToggleReverse,
}: {
  sort: GemsSortKey;
  reversed: boolean;
  onSortChange: (s: GemsSortKey) => void;
  onToggleReverse: () => void;
}) {
  const active = GEMS_SORTS.find((s) => s.key === sort)!;
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-full border border-border/60 bg-card/40 px-2 py-1.5 backdrop-blur">
      <div className="flex items-center gap-1">
        {GEMS_SORTS.map((s) => {
          const on = s.key === sort;
          return (
            <button
              key={s.key}
              onClick={() => onSortChange(s.key)}
              className={cn(
                "rounded-full px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors",
                on
                  ? "bg-[var(--gradient-otaku)] text-white shadow-[var(--neon-glow)]"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {s.label}
            </button>
          );
        })}
      </div>
      <div className="flex items-center gap-2 pr-2">
        <span className="hidden text-[11px] font-medium uppercase tracking-wider text-muted-foreground sm:inline">
          {reversed ? active.reversed : active.normal}
        </span>
        <button
          onClick={onToggleReverse}
          aria-label="Toggle sort direction"
          className={cn(
            "flex size-8 items-center justify-center rounded-full border border-border/60 bg-background/60 transition-all",
            reversed ? "border-primary/60 text-primary shadow-[var(--neon-glow)]" : "text-muted-foreground hover:text-foreground",
          )}
        >
          <ArrowUpDown className={cn("size-4 transition-transform", reversed && "rotate-180")} />
        </button>
      </div>
    </div>
  );
}
