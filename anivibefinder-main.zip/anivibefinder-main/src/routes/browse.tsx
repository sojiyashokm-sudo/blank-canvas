import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useInfiniteQuery } from "@tanstack/react-query";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { Loader2, X } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { AnimeCard } from "@/components/anime-card";
import { useCardDensity } from "@/hooks/use-prefs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { browse, GENRES, FORMATS, SORTS, type MediaFormat, type MediaSeason, type MediaSort } from "@/lib/anilist";

const SEASONS: MediaSeason[] = ["WINTER", "SPRING", "SUMMER", "FALL"];

const searchSchema = z.object({
  genres: fallback(z.string().array(), []).default([]),
  year: fallback(z.number().int().optional(), undefined),
  season: fallback(z.enum(["WINTER","SPRING","SUMMER","FALL"]).optional(), undefined),
  format: fallback(z.enum(["TV","TV_SHORT","MOVIE","SPECIAL","OVA","ONA","MUSIC"]).optional(), undefined),
  sort: fallback(z.enum(["POPULARITY_DESC","SCORE_DESC","TRENDING_DESC","START_DATE_DESC","FAVOURITES_DESC","UPDATED_AT_DESC"]), "POPULARITY_DESC").default("POPULARITY_DESC"),
});

export const Route = createFileRoute("/browse")({
  head: () => ({
    meta: [
      { title: "Browse anime by genre, year & season — OtakuVerse" },
      { name: "description", content: "Filter the entire AniList catalog by genre, year, season, and format. Discover your next favorite anime." },
      { property: "og:title", content: "Browse anime — OtakuVerse" },
      { property: "og:description", content: "Filter the entire anime catalog by genre, year, season, and format." },
    ],
  }),
  validateSearch: zodValidator(searchSchema),
  component: BrowsePage,
});

function BrowsePage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/browse" });

  const query = useInfiniteQuery({
    queryKey: ["browse", search],
    queryFn: ({ pageParam }) =>
      browse(
        {
          genres: search.genres.length ? search.genres : undefined,
          year: search.year,
          season: search.season,
          format: search.format,
          sort: search.sort,
        },
        pageParam,
      ),
    initialPageParam: 1,
    getNextPageParam: (last, all) => (last.hasNextPage ? all.length + 1 : undefined),
  });

  const density = useCardDensity();
  const items = query.data?.pages.flatMap((p) => p.items) ?? [];
  const years = Array.from({ length: 50 }, (_, i) => new Date().getFullYear() + 1 - i);

  type Search = typeof search;
  function update(patch: Partial<Search>) {
    navigate({ search: (prev: Search) => ({ ...prev, ...patch }) });
  }

  function toggleGenre(g: string) {
    const next = search.genres.includes(g) ? search.genres.filter((x: string) => x !== g) : [...search.genres, g];
    update({ genres: next });
  }

  const activeCount = search.genres.length + (search.year ? 1 : 0) + (search.season ? 1 : 0) + (search.format ? 1 : 0);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-6 flex items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-black tracking-tight">Browse</h1>
            <p className="text-sm text-muted-foreground">Filter every anime on AniList.</p>
          </div>
          <Select value={search.sort} onValueChange={(v) => update({ sort: v as MediaSort })}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              {SORTS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
          {/* Filter sidebar */}
          <aside className="space-y-5 rounded-xl border border-border/60 bg-card/40 p-4 backdrop-blur">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-widest text-primary">Filters {activeCount > 0 && `(${activeCount})`}</h2>
              {activeCount > 0 && (
                <button onClick={() => navigate({ search: { genres: [], year: undefined, season: undefined, format: undefined, sort: search.sort } })} className="text-xs text-muted-foreground hover:text-foreground">Clear</button>
              )}
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Format</label>
              <Select value={search.format ?? "any"} onValueChange={(v) => update({ format: v === "any" ? undefined : (v as MediaFormat) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any format</SelectItem>
                  {FORMATS.map((f) => <SelectItem key={f} value={f}>{f.replace("_", " ")}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Year</label>
              <Select value={search.year ? String(search.year) : "any"} onValueChange={(v) => update({ year: v === "any" ? undefined : Number(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="any">Any year</SelectItem>
                  {years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Season</label>
              <Select value={search.season ?? "any"} onValueChange={(v) => update({ season: v === "any" ? undefined : (v as MediaSeason) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any season</SelectItem>
                  {SEASONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Genres</label>
              <div className="flex flex-wrap gap-1.5">
                {GENRES.map((g) => {
                  const on = search.genres.includes(g);
                  return (
                    <button
                      key={g}
                      onClick={() => toggleGenre(g)}
                      className={`rounded-full px-2.5 py-1 text-xs font-medium transition-colors ${
                        on ? "bg-[var(--gradient-otaku)] text-white shadow-[var(--neon-glow)]" : "bg-card text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {g}
                      {on && <X className="ml-1 inline size-3" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </aside>

          {/* Results */}
          <section>
            {query.isLoading ? (
              <div className="flex items-center justify-center py-20 text-muted-foreground">
                <Loader2 className="mr-2 size-5 animate-spin text-primary" /> Loading…
              </div>
            ) : items.length === 0 ? (
              <div className="rounded-xl border border-dashed border-border p-10 text-center text-muted-foreground">
                No anime match these filters.
              </div>
            ) : (
              <>
                <div className={density === "detailed" ? "flex flex-col gap-2" : "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5"}>
                  {items.map((a) => <AnimeCard key={a.id} anime={a} />)}
                </div>
                {query.hasNextPage && (
                  <div className="mt-8 flex justify-center">
                    <Button onClick={() => query.fetchNextPage()} disabled={query.isFetchingNextPage} className="rounded-full bg-[var(--gradient-otaku)] px-8 py-6 text-white shadow-[var(--neon-glow)]">
                      {query.isFetchingNextPage ? <><Loader2 className="mr-2 size-4 animate-spin" /> Loading…</> : "Load more"}
                    </Button>
                  </div>
                )}
              </>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}
