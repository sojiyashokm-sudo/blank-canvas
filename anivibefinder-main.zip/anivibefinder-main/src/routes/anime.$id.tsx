import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Star, Calendar, Clock, Tv, ExternalLink, Play } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/site-header";
import { AnimeCard } from "@/components/anime-card";
import { WatchlistControls } from "@/components/watchlist-controls";
import { getAnimeDetail, getRecommendations, getJikanEpisodes, type EpisodeInfo } from "@/lib/anilist";

type JikanRec = {
  malId: number;
  title: string;
  image: string;
  url: string;
  score: number | null;
  members: number | null;
};

async function getJikanRecommendations(malId: number): Promise<JikanRec[]> {
  try {
    const recRes = await fetch(`https://api.jikan.moe/v4/anime/${malId}/recommendations`);
    if (!recRes.ok) return [];
    const recJson = await recRes.json();
    const entries = ((recJson?.data ?? []) as any[]).slice(0, 4).map((r) => r.entry).filter(Boolean);
    // Fetch full info (score/members) for each in parallel
    const full = await Promise.all(
      entries.map(async (e: any) => {
        try {
          const r = await fetch(`https://api.jikan.moe/v4/anime/${e.mal_id}`);
          if (!r.ok) return null;
          const j = await r.json();
          const d = j?.data;
          return {
            malId: e.mal_id as number,
            title: (d?.title_english ?? d?.title ?? e.title) as string,
            image: (d?.images?.webp?.image_url ?? d?.images?.jpg?.image_url ?? e.images?.webp?.image_url ?? e.images?.jpg?.image_url ?? "") as string,
            url: (d?.url ?? e.url) as string,
            score: (d?.score ?? null) as number | null,
            members: (d?.members ?? null) as number | null,
          } as JikanRec;
        } catch {
          return null;
        }
      }),
    );
    return full.filter((x): x is JikanRec => !!x);
  } catch {
    return [];
  }
}

function formatMembers(n: number | null): string {
  if (n == null) return "—";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

export const Route = createFileRoute("/anime/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `Anime details — OtakuVerse` },
      { name: "description", content: `Watch trailer, see characters, episodes, and rating for AniList #${params.id}.` },
    ],
  }),
  component: AnimePage,
  errorComponent: ({ error }) => (
    <div className="p-10 text-center text-destructive">Failed to load: {error.message}</div>
  ),
  notFoundComponent: () => <div className="p-10 text-center">Anime not found.</div>,
});

function AnimePage() {
  const { id } = Route.useParams();
  const animeId = Number(id);

  const detail = useQuery({
    queryKey: ["anime-detail", animeId],
    queryFn: () => getAnimeDetail(animeId),
  });
  const similar = useQuery({
    queryKey: ["anime-recs", animeId],
    queryFn: () => getRecommendations(animeId),
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      {detail.isLoading ? (
        <div className="flex items-center justify-center py-32 text-muted-foreground">
          <Loader2 className="mr-2 size-5 animate-spin text-primary" /> Loading…
        </div>
      ) : !detail.data ? (
        <div className="p-10 text-center text-muted-foreground">Anime not found.</div>
      ) : (
        <Detail anime={detail.data} similar={similar.data ?? []} />
      )}
    </div>
  );
}

function Detail({ anime, similar }: { anime: NonNullable<Awaited<ReturnType<typeof getAnimeDetail>>>; similar: Awaited<ReturnType<typeof getRecommendations>> }) {
  return (
    <>
      {/* Banner — only rendered when the anime actually has banner artwork */}
      {anime.bannerImage ? (
        <div className="relative h-64 overflow-hidden sm:h-80 md:h-96">
          <img src={anime.bannerImage} alt="" className="size-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        </div>
      ) : null}

      <main
        className={`mx-auto max-w-7xl px-4 pb-20 ${anime.bannerImage ? "-mt-32" : "pt-8"}`}
      >

        <div className="grid gap-6 md:grid-cols-[220px_1fr]">
          <div className="space-y-4">
            <img
              src={anime.coverImage}
              alt={anime.title}
              className="w-full max-w-[220px] rounded-xl border border-border shadow-[var(--neon-glow)]"
            />
            <WatchlistControls anime={anime} />
          </div>

          <div className={`space-y-4 ${anime.bannerImage ? "pt-32" : ""}`}>
            <h1 className="text-3xl font-black tracking-tight sm:text-4xl">{anime.title}</h1>
            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              {anime.score != null && (
                <span className="flex items-center gap-1 text-primary">
                  <Star className="size-4 fill-primary" /> <strong>{anime.score.toFixed(1)}</strong>
                </span>
              )}
              {anime.year && <span className="flex items-center gap-1"><Calendar className="size-4" /> {anime.year}</span>}
              {anime.episodes && <span className="flex items-center gap-1"><Tv className="size-4" /> {anime.episodes} ep</span>}
              {anime.duration && <span className="flex items-center gap-1"><Clock className="size-4" /> {anime.duration}m</span>}
              {anime.format && <Badge variant="outline">{anime.format}</Badge>}
              {anime.status && <Badge variant="outline">{anime.status.replace(/_/g, " ")}</Badge>}
            </div>

            <MetadataStrip anime={anime} />
            <CompactTagsGrid anime={anime} />
            <AlternateNamesBar anime={anime} />

            {anime.nextAiringEpisode && (
              <div className="rounded-lg border border-primary/40 bg-primary/10 p-3 text-sm">
                <span className="font-bold text-primary">Next episode:</span> Ep {anime.nextAiringEpisode.episode} in {formatCountdown(anime.nextAiringEpisode.timeUntilAiring)}
              </div>
            )}

            {anime.description && (
              <ExpandableSynopsis html={anime.description} />
            )}
          </div>
        </div>

        {/* Live MAL Recommendations */}
        <MalRecommendations malId={anime.idMal} fallbackTitle={anime.title} />

        {/* Trailer */}
        {anime.trailer && anime.trailer.site === "youtube" && (
          <section className="mt-10">
            <SectionHeading>Trailer</SectionHeading>
            <div className="aspect-video overflow-hidden rounded-xl border border-border">
              <iframe
                src={`https://www.youtube.com/embed/${anime.trailer.id}`}
                title="Trailer"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="size-full"
              />
            </div>
          </section>
        )}

        {/* Characters */}
        {anime.characters.length > 0 && (
          <section className="mt-10">
            <SectionHeading>Characters & Voice Actors</SectionHeading>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {anime.characters.map((c) => (
                <div key={c.id} className="flex overflow-hidden rounded-xl border border-border/60 bg-card/60">
                  <img src={c.image ?? ""} alt={c.name} className="h-24 w-16 object-cover" />
                  <div className="flex flex-1 flex-col justify-between p-2 text-xs">
                    <div>
                      <div className="font-bold">{c.name}</div>
                      <div className="text-muted-foreground">{c.role}</div>
                    </div>
                    {c.voiceActor && (
                      <div className="text-right text-muted-foreground">
                        <div className="font-medium text-foreground/90">{c.voiceActor.name}</div>
                        <div className="text-[10px]">{c.voiceActor.language}</div>
                      </div>
                    )}
                  </div>
                  {c.voiceActor?.image && (
                    <img src={c.voiceActor.image} alt={c.voiceActor.name} className="h-24 w-16 object-cover" />
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Episodes */}
        <EpisodesSection anime={anime} />


        {/* Where to watch */}
        {anime.externalLinks.filter((l) => ["Crunchyroll","Netflix","Hulu","HiDive","Funimation","Amazon","VRV"].some((s) => l.site.includes(s))).length > 0 && (
          <section className="mt-10">
            <SectionHeading>Where to Watch</SectionHeading>
            <div className="flex flex-wrap gap-2">
              {anime.externalLinks.map((l) => (
                <Button key={l.id} asChild variant="outline" size="sm" className="rounded-full">
                  <a href={l.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="mr-1.5 size-3" /> {l.site}
                  </a>
                </Button>
              ))}
            </div>
          </section>
        )}

        {/* Tags */}
        {anime.tags.length > 0 && (
          <section className="mt-10">
            <SectionHeading>Tags</SectionHeading>
            <div className="flex flex-wrap gap-1.5">
              {anime.tags.map((t) => (
                <Badge key={t.name} variant="secondary" className="text-xs">
                  {t.name} <span className="ml-1 opacity-60">{t.rank}%</span>
                </Badge>
              ))}
            </div>
          </section>
        )}

        {/* Similar */}
        {similar.length > 0 && (
          <section className="mt-10">
            <SectionHeading>Similar Anime</SectionHeading>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
              {similar.map((a) => <AnimeCard key={a.id} anime={a} />)}
            </div>
          </section>
        )}
      </main>
    </>
  );
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-4 text-sm font-bold uppercase tracking-widest text-primary">{children}</h2>
  );
}

function ExpandableSynopsis({ html }: { html: string }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="space-y-2">
      <div className="relative">
        <p
          className={`whitespace-pre-line text-sm leading-relaxed text-foreground/85 transition-all ${expanded ? "" : "line-clamp-3"}`}
          dangerouslySetInnerHTML={{ __html: html }}
        />
        {!expanded && (
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-8 bg-gradient-to-t from-background to-transparent" />
        )}
      </div>
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="text-xs font-bold uppercase tracking-widest text-amber-400 transition-colors hover:text-amber-300"
      >
        {expanded ? "Show Less" : "Show More"}
      </button>
    </div>
  );
}

function MalRecommendations({ malId, fallbackTitle }: { malId: number | null; fallbackTitle: string }) {
  const resolved = useQuery({
    queryKey: ["jikan-mal-id", malId, fallbackTitle],
    queryFn: async () => {
      if (malId) return malId;
      const res = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(fallbackTitle)}&limit=1`);
      if (!res.ok) return null;
      const j = await res.json();
      return (j?.data?.[0]?.mal_id ?? null) as number | null;
    },
  });

  const recs = useQuery({
    queryKey: ["jikan-recs", resolved.data],
    queryFn: () => getJikanRecommendations(resolved.data as number),
    enabled: !!resolved.data,
  });

  const loading = resolved.isLoading || recs.isLoading;
  const items = recs.data ?? [];

  if (!loading && items.length === 0) return null;

  return (
    <section className="mt-10">
      <SectionHeading>Recommended Anime</SectionHeading>
      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex gap-3 rounded-xl border border-border/60 bg-card/40 p-3">
              <div className="h-24 w-16 shrink-0 animate-pulse rounded bg-muted" />
              <div className="flex-1 space-y-2 py-1">
                <div className="h-4 w-3/4 animate-pulse rounded bg-muted" />
                <div className="h-3 w-1/2 animate-pulse rounded bg-muted" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {items.map((r) => (
            <a
              key={r.malId}
              href={r.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex gap-3 rounded-xl border border-border/60 bg-card/60 p-3 transition hover:border-primary/60 hover:shadow-[var(--neon-glow)]"
            >
              {r.image ? (
                <img src={r.image} alt="" className="h-24 w-16 shrink-0 rounded object-cover" />
              ) : (
                <div className="h-24 w-16 shrink-0 rounded bg-muted" />
              )}
              <div className="min-w-0 flex-1">
                <h3 className="line-clamp-2 text-sm font-bold group-hover:text-primary">{r.title}</h3>
                <div className="mt-2 inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-2.5 py-1 text-[11px] font-semibold text-amber-300">
                  <Star className="size-3 fill-amber-400 text-amber-400" />
                  <span>MAL: {r.score != null ? r.score.toFixed(2) : "—"}</span>
                  <span className="opacity-60">•</span>
                  <span>{formatMembers(r.members)} users</span>
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </section>
  );
}

function formatCountdown(seconds: number) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

function formatRelativeTime(seconds: number): string {
  const now = Math.floor(Date.now() / 1000);
  const diff = Math.max(0, now - seconds);
  const days = Math.floor(diff / 86400);
  if (days === 0) return "today";
  if (days === 1) return "1 day ago";
  if (days < 30) return `${days} days ago`;
  const months = Math.floor(days / 30);
  if (months === 1) return "1 month ago";
  if (months < 12) return `${months} months ago`;
  const years = Math.floor(months / 12);
  return years === 1 ? "1 year ago" : `${years} years ago`;
}

function formatStartDate(date: { year: number | null; month: number | null; day: number | null }): string {
  if (!date.year) return "Release date TBA";
  const parts: string[] = [];
  if (date.day) parts.push(String(date.day).padStart(2, "0"));
  if (date.month) parts.push(String(date.month).padStart(2, "0"));
  parts.push(String(date.year));
  return parts.join("/");
}

function MetadataStrip({ anime }: { anime: NonNullable<Awaited<ReturnType<typeof getAnimeDetail>>> }) {
  const studio = anime.studios[0]?.name ?? "Unknown Studio";
  const episodeText = anime.episodes ? `${anime.episodes} Episodes` : null;
  const dateText = anime.updatedAt
    ? formatRelativeTime(anime.updatedAt)
    : anime.startDate?.year
      ? formatStartDate(anime.startDate)
      : "Release date TBA";

  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
      <span className="font-semibold text-primary">{studio}</span>
      {episodeText && (
        <>
          <span className="text-border">•</span>
          <span>{episodeText}</span>
        </>
      )}
      <span className="text-border">•</span>
      <span>{dateText}</span>
    </div>
  );
}

function CompactTagsGrid({ anime }: { anime: NonNullable<Awaited<ReturnType<typeof getAnimeDetail>>> }) {
  const items = [...anime.genres, ...anime.tags.map((t) => t.name)].slice(0, 14);
  if (items.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((label) => (
        <span
          key={label}
          className="rounded-md bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground"
        >
          {label}
        </span>
      ))}
    </div>
  );
}

function AlternateNamesBar({ anime }: { anime: NonNullable<Awaited<ReturnType<typeof getAnimeDetail>>> }) {
  const names = [
    anime.titleVariants.english,
    anime.titleVariants.romaji,
    anime.titleVariants.native,
    ...anime.synonyms,
  ].filter((n): n is string => !!n && n !== anime.title);

  const displayNames = names.length > 0 ? names : ["No alternate titles available"];

  return (
    <div className="space-y-2">
      <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Alternate Names
      </h3>
      <div className="flex flex-wrap gap-2">
        {displayNames.map((name) => (
          <span
            key={name}
            className="rounded-full border border-border bg-transparent px-3 py-1 text-xs text-muted-foreground"
          >
            {name}
          </span>
        ))}
      </div>
    </div>
  );
}

function EpisodesSection({
  anime,
}: {
  anime: NonNullable<Awaited<ReturnType<typeof getAnimeDetail>>>;
}) {
  const jikan = useQuery({
    queryKey: ["jikan-episodes", anime.idMal],
    queryFn: () => getJikanEpisodes(anime.idMal as number),
    enabled: !!anime.idMal,
  });

  // Merge sources: prefer AniList streaming episodes (they have thumbnails/urls),
  // enrich with Jikan titles when missing, and fall back to placeholder cards
  // based on total episode count so the grid is always populated.
  const streaming = anime.streamingEpisodes ?? [];
  const jikanEps: EpisodeInfo[] = jikan.data ?? [];
  const totalCount =
    anime.episodes ??
    Math.max(streaming.length, jikanEps.length, anime.nextAiringEpisode?.episode ?? 0);

  if (!totalCount) return null;

  type Row = {
    number: number;
    title: string | null;
    thumbnail: string | null;
    url: string | null;
    site: string | null;
  };

  const rows: Row[] = Array.from({ length: totalCount }, (_, i) => {
    const num = i + 1;
    const s = streaming[i];
    const j = jikanEps.find((e) => e.number === num);
    return {
      number: num,
      title: j?.title ?? s?.title ?? `Episode ${num}`,
      thumbnail: s?.thumbnail ?? null,
      url: s?.url ?? j?.url ?? null,
      site: s?.site ?? j?.site ?? null,
    };
  });

  return (
    <section className="mt-10">
      <SectionHeading>Episodes</SectionHeading>
      <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
        {rows.slice(0, 60).map((ep) => {
          const Wrapper: any = ep.url ? "a" : "div";
          const wrapperProps = ep.url
            ? { href: ep.url, target: "_blank", rel: "noopener noreferrer" }
            : {};
          return (
            <Wrapper
              key={ep.number}
              {...wrapperProps}
              className="group relative block overflow-hidden rounded-xl border border-border/60 transition hover:border-primary/60"
            >
              {ep.thumbnail ? (
                <img
                  src={ep.thumbnail}
                  alt=""
                  className="aspect-video w-full object-cover"
                />
              ) : (
                <div className="relative aspect-video w-full overflow-hidden bg-muted">
                  <img
                    src={anime.coverImage}
                    alt=""
                    className="size-full scale-110 object-cover blur-sm brightness-50 transition duration-300 group-hover:scale-125"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-primary/90">
                      Episode
                    </span>
                    <span className="text-3xl font-black text-foreground drop-shadow">
                      {ep.number}
                    </span>
                  </div>
                </div>
              )}
              <div className="p-2 text-xs">
                <div className="line-clamp-2 font-medium">
                  {ep.number}. {ep.title}
                </div>
                {ep.site && (
                  <div className="mt-1 flex items-center gap-1 text-muted-foreground">
                    <Play className="size-3" /> {ep.site}
                  </div>
                )}
              </div>
            </Wrapper>
          );
        })}
      </div>
    </section>
  );
}
