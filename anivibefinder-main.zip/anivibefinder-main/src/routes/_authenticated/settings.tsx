import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";

import {
  Bell,
  BellOff,
  BellRing,
  CheckCircle2,
  XCircle,
  Upload,
  User as UserIcon,
  Loader2,

} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { PALETTES } from "@/lib/theme-palettes";
import { setTheme } from "@/lib/apply-theme";
import {
  currentPermission,
  isEnabled,
  notificationsSupported,
  requestNotificationPermission,
  setEnabled,
} from "@/lib/notifications";

import {
  BLUR18_KEY,
  DENSITY_KEY,
  LANDING_KEY,
  NOTIF_KEY,
  writePref,
} from "@/hooks/use-prefs";

export const Route = createFileRoute("/_authenticated/settings")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Settings — OtakuVerse" },
      { name: "description", content: "Manage account, appearance, and viewing preferences." },
    ],
  }),
  component: SettingsPage,
});

const PREFS_KEY = "otakuverse:prefs";
type Prefs = {
  displayName: string;
  tagline: string;
  email: string;
  avatar: string;
  banner: string;
  theme: string;
  landing: "home" | "browse" | "list";
  density: "compact" | "detailed";
  blurAdult: boolean;
};
const DEFAULTS: Prefs = {
  displayName: "",
  tagline: "",
  email: "",
  avatar: "",
  banner: "",
  theme: "noir",
  landing: "home",
  density: "compact",
  blurAdult: true,
};


function loadPrefs(): Prefs {
  if (typeof window === "undefined") return DEFAULTS;
  let base: Prefs = DEFAULTS;
  try {
    base = { ...DEFAULTS, ...JSON.parse(localStorage.getItem(PREFS_KEY) ?? "{}") };
  } catch {
    base = DEFAULTS;
  }
  // Individual keys are the source of truth for the app-wide prefs.
  const landing = localStorage.getItem(LANDING_KEY);
  const density = localStorage.getItem(DENSITY_KEY);
  const blur = localStorage.getItem(BLUR18_KEY);
  return {
    ...base,
    landing: (landing === "browse" || landing === "list" ? landing : landing === "home" ? "home" : base.landing) as Prefs["landing"],
    density: (density === "detailed" ? "detailed" : density === "compact" ? "compact" : base.density) as Prefs["density"],
    blurAdult: blur == null ? base.blurAdult : blur === "true",
  };
}

function SettingsPage() {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULTS);
  const [enabled, setEnabledState] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">("default");
  const [userId, setUserId] = useState<string | null>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [savingProfile, setSavingProfile] = useState(false);


  useEffect(() => {
    setPrefs(loadPrefs());
    const initialEnabled = typeof window !== "undefined" && localStorage.getItem(NOTIF_KEY) === "true";
    setEnabledState(initialEnabled || isEnabled());
    setPermission(currentPermission());
  }, []);

  // Keep permission text in sync with the browser's current value.
  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    const refresh = () => setPermission(Notification.permission);
    window.addEventListener("focus", refresh);
    const id = window.setInterval(refresh, 2000);
    return () => {
      window.removeEventListener("focus", refresh);
      window.clearInterval(id);
    };
  }, []);

  // Fetch auth user + profile from Supabase
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setProfileLoading(true);
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;
      if (!user || cancelled) {
        setProfileLoading(false);
        return;
      }
      setUserId(user.id);

      const { data: profile, error } = await supabase
        .from("profiles")
        .select("display_name, tagline, avatar_url")
        .eq("user_id", user.id)
        .maybeSingle();

      if (cancelled) return;
      if (error) {
        console.error("Failed to load profile", error);
        toast.error("Couldn't load your profile.");
      }

      setPrefs((p) => ({
        ...p,
        email: user.email ?? "",
        displayName: profile?.display_name ?? p.displayName ?? "",
        tagline: profile?.tagline ?? p.tagline ?? "",
        avatar: profile?.avatar_url ?? p.avatar ?? "",
      }));

      setProfileLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  }, [prefs]);

  const update = <K extends keyof Prefs>(k: K, v: Prefs[K]) =>
    setPrefs((p) => ({ ...p, [k]: v }));

  const supported = notificationsSupported();

  async function saveProfile() {
    if (!userId) return toast.error("You must be signed in.");
    setSavingProfile(true);
    const { error } = await supabase.from("profiles").upsert(
      {
        user_id: userId,
        display_name: prefs.displayName || null,
        tagline: prefs.tagline || null,
        avatar_url: prefs.avatar || null,
      },

      { onConflict: "user_id" },
    );
    setSavingProfile(false);
    if (error) {
      console.error(error);
      return toast.error(error.message || "Failed to save profile.");
    }
    toast.success("Profile saved.");
  }

  async function toggleNotif(next: boolean) {
    writePref(NOTIF_KEY, next ? "true" : "false");
    if (!supported) {
      setEnabledState(next);
      if (next) toast.error("Your browser doesn't support notifications.");
      return;
    }
    if (next) {
      const perm = await requestNotificationPermission();
      setPermission(perm);
      if (perm !== "granted") {
        setEnabledState(false);
        writePref(NOTIF_KEY, "false");
        toast.error(
          perm === "denied"
            ? "Notifications are blocked in your browser."
            : "Notification permission wasn't granted.",
        );
        return;
      }
      setEnabled(true);
      setEnabledState(true);
      toast.success("Episode notifications on.");
    } else {
      setEnabled(false);
      setEnabledState(false);
      toast("Episode notifications off.");
    }
  }





  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-4xl px-4 py-10">
        <header className="mb-8">
          <h1 className="text-3xl font-black tracking-tight">Settings</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            A quiet, deliberate control panel for OtakuVerse.
          </p>
        </header>

        <div className="space-y-6">
          <Section
            eyebrow="01"
            title="Account & Profile"
            description="Your identity across OtakuVerse."
          >
            <ProfileMedia
              avatar={prefs.avatar}
              onAvatar={(v) => update("avatar", v)}
              banner={prefs.banner}
              onBanner={(v) => update("banner", v)}
            />


            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <Field label="Display Name">
                <Input
                  value={prefs.displayName}
                  onChange={(e) => update("displayName", e.target.value)}
                  placeholder="Your name"
                />
              </Field>
              <Field label="Email Address">
                <Input
                  type="email"
                  value={prefs.email}
                  readOnly
                  disabled={profileLoading}
                  placeholder={profileLoading ? "Loading…" : ""}
                  className="cursor-not-allowed opacity-80"
                />
              </Field>
              <Field label="Profile Status / Custom Tagline" className="sm:col-span-2">
                <Textarea
                  value={prefs.tagline}
                  onChange={(e) => update("tagline", e.target.value)}
                  placeholder="Currently marathoning..."
                  rows={2}
                />
              </Field>
            </div>

            <div className="mt-4 flex justify-end">
              <Button
                onClick={saveProfile}
                disabled={savingProfile || profileLoading || !userId}
                className="rounded-none"
              >
                {savingProfile ? (
                  <><Loader2 className="mr-2 size-4 animate-spin" /> Saving…</>
                ) : (
                  "Save changes"
                )}
              </Button>
            </div>

          </Section>



          <Section
            eyebrow="02"
            title="Appearance & Theme Harmony"
            description="Pick a palette. The harmony card updates in real time."
          >
            <ThemeHarmony value={prefs.theme} onChange={(v) => { update("theme", v); setTheme(v); }} />
          </Section>


          <Section
            eyebrow="03"
            title="Interface & Grid Controls"
            description="How the app opens and lays out."
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Default Landing Page">
                <Select
                  value={prefs.landing}
                  onValueChange={(v) => { update("landing", v as Prefs["landing"]); writePref(LANDING_KEY, v); }}
                >
                  <SelectTrigger className="rounded-none">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="home">Home</SelectItem>
                    <SelectItem value="browse">Browse</SelectItem>
                    <SelectItem value="list">My List</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Card Density Style">
                <Segmented
                  value={prefs.density}
                  onChange={(v) => { update("density", v as Prefs["density"]); writePref(DENSITY_KEY, v); }}
                  options={[
                    { value: "compact", label: "Compact Grid" },
                    { value: "detailed", label: "Detailed List" },
                  ]}
                />
              </Field>
            </div>

            <Separator className="my-6 bg-border" />
            <h3 className="text-sm font-semibold">Content Filtering</h3>
            <div className="mt-3">
              <ToggleRow
                label="Blur / Filter 18+ Adult Content"
                description="Hide mature covers and titles behind a soft blur."
                checked={prefs.blurAdult}
                onChange={(v) => { update("blurAdult", v); writePref(BLUR18_KEY, v ? "true" : "false"); }}
              />
            </div>
          </Section>

          <Section
            eyebrow="04"
            title="Notifications"
            description="Native alerts when new episodes air."
          >
            <div className="flex items-start gap-4">
              <div className="grid size-10 shrink-0 place-items-center border border-border bg-muted">
                <BellRing className="size-5" />
              </div>
              <div className="flex-1">
                <ToggleRow
                  label="New episode notifications"
                  description="Get a device notification when a Currently Watching title airs."
                  checked={enabled}
                  onChange={toggleNotif}
                />
                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                  <PermissionBadge permission={permission} supported={supported} />
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      alert("Test Notification: Your notification system is working perfectly.");
                    }}
                    className="h-7 rounded-none"
                  >
                    <Bell className="mr-1.5 size-3.5" /> Send test
                  </Button>

                </div>
              </div>
            </div>
          </Section>
        </div>
      </main>
    </div>
  );
}

/* ---------- pieces ---------- */

function Section({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <section className="border border-border bg-card/40 p-6">
      <div className="mb-5 flex items-baseline gap-3 border-b border-border pb-4">
        <span className="font-mono text-xs text-muted-foreground">{eyebrow}</span>
        <div>
          <h2 className="text-lg font-bold tracking-tight">{title}</h2>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
      {children}
    </section>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <Label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </Label>
      {children}
    </div>
  );
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border border-border bg-background/40 px-4 py-3 transition-colors hover:bg-muted/40">
      <div>
        <p className="text-sm font-medium">{label}</p>
        {description && (
          <p className="mt-0.5 text-xs text-muted-foreground">{description}</p>
        )}
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

function Segmented<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string }[];
}) {
  return (
    <div className="inline-flex w-full border border-border">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={cn(
              "flex-1 px-3 py-2 text-sm font-medium transition-colors",
              active
                ? "bg-muted text-foreground"
                : "bg-transparent text-muted-foreground hover:bg-muted/60",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function ProfileMedia({
  avatar,
  onAvatar,
  banner,
  onBanner,
}: {
  avatar: string;
  onAvatar: (v: string) => void;
  banner: string;
  onBanner: (v: string) => void;
}) {
  const avatarRef = useRef<HTMLInputElement>(null);
  const bannerRef = useRef<HTMLInputElement>(null);

  function handleFile(file: File | undefined, cb: (v: string) => void) {
    if (!file) return;
    if (file.size > 7 * 1024 * 1024) return toast.error("Max 7MB.");
    const reader = new FileReader();
    reader.onload = () => cb(String(reader.result));
    reader.readAsDataURL(file);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button
          type="button"
          onClick={() => avatarRef.current?.click()}
          className="grid size-20 place-items-center overflow-hidden rounded-full border border-border bg-muted"
          style={
            avatar ? { backgroundImage: `url(${avatar})`, backgroundSize: "cover", backgroundPosition: "center" } : undefined
          }
          aria-label="Upload avatar"
        >
          {!avatar && <UserIcon className="size-7 text-muted-foreground" />}
        </button>
        <div>
          <p className="text-sm font-medium">Profile Photo</p>
          <p className="text-xs text-muted-foreground">Square PNG or JPG, up to 7MB.</p>
          <button
            type="button"
            onClick={() => avatarRef.current?.click()}
            className="mt-2 inline-flex items-center gap-1.5 border border-border bg-background px-2.5 py-1 text-xs hover:bg-muted"
          >
            <Upload className="size-3.5" /> Upload avatar
          </button>
        </div>
        <input
          ref={avatarRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0], onAvatar)}
        />
      </div>

      <div className="flex items-center gap-4">
        <button
          type="button"
          onClick={() => bannerRef.current?.click()}
          className="grid h-20 w-36 place-items-center overflow-hidden border border-border bg-muted"
          style={
            banner ? { backgroundImage: `url(${banner})`, backgroundSize: "cover", backgroundPosition: "center" } : undefined
          }
          aria-label="Upload banner"
        >
          {!banner && <Upload className="size-5 text-muted-foreground" />}
        </button>
        <div>
          <p className="text-sm font-medium">Profile Banner</p>
          <p className="text-xs text-muted-foreground">Wide PNG or JPG, up to 7MB.</p>
          <button
            type="button"
            onClick={() => bannerRef.current?.click()}
            className="mt-2 inline-flex items-center gap-1.5 border border-border bg-background px-2.5 py-1 text-xs hover:bg-muted"
          >
            <Upload className="size-3.5" /> Upload banner
          </button>
        </div>
        <input
          ref={bannerRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0], onBanner)}
        />
      </div>
    </div>
  );
}


function PermissionBadge({
  permission,
  supported,
}: {
  permission: NotificationPermission | "unsupported";
  supported: boolean;
}) {
  if (!supported) {
    return (
      <span className="inline-flex items-center gap-1 border border-border bg-muted px-2 py-0.5 text-muted-foreground">
        <BellOff className="size-3" /> Unsupported
      </span>
    );
  }
  if (permission === "granted") {
    return (
      <span className="inline-flex items-center gap-1 border border-border bg-muted px-2 py-0.5">
        <CheckCircle2 className="size-3" /> Permission granted
      </span>
    );
  }
  if (permission === "denied") {
    return (
      <span className="inline-flex items-center gap-1 border border-destructive/40 bg-destructive/10 px-2 py-0.5 text-destructive">
        <XCircle className="size-3" /> Blocked by browser
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 border border-border bg-muted/60 px-2 py-0.5 text-muted-foreground">
      <Bell className="size-3" /> Not requested yet
    </span>
  );
}

function isDark(hex: string): boolean {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum < 0.55;
}

function ThemeHarmony({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const palette = useMemo(
    () => PALETTES.find((p) => p.id === value) ?? PALETTES[0],
    [value],
  );

  return (
    <>
      <Field label="Select Active Theme">
        <Select value={palette.id} onValueChange={onChange}>
          <SelectTrigger className="rounded-none">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="max-h-80">
            {PALETTES.map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </Field>

      <div className="mt-5 border border-border bg-card p-5">
        <div className="flex items-baseline justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">
              Theme Harmony Palette
            </p>
            <h4 className="mt-1 text-lg font-bold">{palette.label}</h4>
          </div>
          <p className="text-right text-xs text-muted-foreground">
            {palette.gradientLabel}
          </p>
        </div>

        <div
          className="mt-4 h-12 w-full rounded-md"
          style={{
            background: `linear-gradient(90deg, ${palette.gradientFrom}, ${palette.gradientTo})`,
          }}
          aria-label={`Gradient from ${palette.gradientFrom} to ${palette.gradientTo}`}
        />

        <div className="mt-4 grid grid-cols-7 gap-2">
          {palette.swatches.map((hex, i) => {
            const dark = isDark(hex);
            return (
              <div
                key={hex + i}
                className="overflow-hidden rounded-md border border-border"
                title={hex}
              >
                <div className="h-10 w-full" style={{ background: hex }} />
                <div
                  className="px-1.5 py-1 text-center"
                  style={{ background: hex, color: dark ? "#F5F5F5" : "#0A0A0A" }}
                >
                  <p className="text-[10px] font-semibold leading-tight">
                    Step {i + 1}
                  </p>
                  <p className="font-mono text-[9px] opacity-80">{hex}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

