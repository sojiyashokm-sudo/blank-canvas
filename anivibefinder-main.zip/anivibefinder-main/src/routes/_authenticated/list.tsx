import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Bookmark, Star, User as UserIcon } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { getMyWatchlist } from "@/lib/watchlist.functions";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/list")({
  head: () => ({
    meta: [{ title: "My List — OtakuVerse" }],
  }),
  component: MyListPage,
});

const TABS = [
  { value: "watching", label: "Watching" },
  { value: "completed", label: "Completed" },
  { value: "planning", label: "Plan to Watch" },
  { value: "paused", label: "On Hold" },
  { value: "dropped", label: "Dropped" },
] as const;

type HeaderProfile = {
  avatar_url: string | null;
  display_name: string | null;
  tagline: string | null;
} | null;

function MyListPage() {
  const { user } = useAuth();
  const userId = user?.id ?? null;

  const { data: profile } = useQuery<HeaderProfile>({
    queryKey: ["header-profile", userId],
    enabled: !!userId,
    staleTime: 0,
    refetchOnWindowFocus: true,
    refetchOnMount: true,
    queryFn: async () => {
      if (!userId) return null;
      const { data } = await supabase
        .from("profiles")
        .select("avatar_url, display_name, tagline")
        .eq("user_id", userId)
        .maybeSingle();
      return (data as HeaderProfile) ?? null;
    },
  });

  const fetchList = useServerFn(getMyWatchlist);
  const q = useQuery({
    queryKey: ["my-watchlist"],
    queryFn: () => fetchList(),
  });

  const grouped: Record<string, NonNullable<typeof q.data>> = {
    watching: [], completed: [], planning: [], paused: [], dropped: [],
  };
  for (const row of q.data ?? []) (grouped[row.status] ??= []).push(row);

  const avatarUrl = profile?.avatar_url?.trim() || "";
  const displayName = profile?.display_name?.trim() || user?.email?.split("@")[0] || "Otaku";
  const tagline = profile?.tagline?.trim() || "";

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        {/* Profile Header — no banner, avatar + name at the top */}
        <section className="mb-8 flex items-center gap-4">
          {avatarUrl ? (
            <span
              className="size-20 shrink-0 rounded-full border-2 border-background bg-muted bg-cover bg-center shadow-sm sm:size-24"
              style={{ backgroundImage: `url(${avatarUrl})` }}
              aria-label="Profile avatar"
            />
          ) : (
            <span className="grid size-20 shrink-0 place-items-center rounded-full border-2 border-background bg-[var(--gradient-otaku)] text-lg font-bold text-white shadow-sm sm:size-24">
              <UserIcon className="size-8 sm:size-10" />
            </span>
          )}

          <div className="min-w-0">
            <h1 className="text-2xl font-black tracking-tight sm:text-3xl">
              {displayName}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {tagline || "No status set."}
            </p>
          </div>
        </section>




        <header className="mb-6 flex items-center gap-2">
          <Bookmark className="size-5 text-primary" />
          <h2 className="text-3xl font-black tracking-tight">My List</h2>
        </header>

        {q.isLoading ? (
          <div className="flex items-center justify-center py-20 text-muted-foreground">
            <Loader2 className="mr-2 size-5 animate-spin text-primary" /> Loading…
          </div>
        ) : (
          <Tabs defaultValue="watching">
            <TabsList className="flex h-auto flex-wrap justify-start gap-1 rounded-full border border-border bg-card/60 p-1 backdrop-blur">
              {TABS.map((t) => (
                <TabsTrigger key={t.value} value={t.value} className="rounded-full px-4 py-1.5 text-xs sm:text-sm data-[state=active]:bg-[var(--gradient-otaku)] data-[state=active]:text-white data-[state=active]:shadow-[var(--neon-glow)]">
                  {t.label} <Badge variant="secondary" className="ml-2 bg-background/30 text-xs">{grouped[t.value].length}</Badge>
                </TabsTrigger>
              ))}
            </TabsList>

            {TABS.map((t) => (
              <TabsContent key={t.value} value={t.value} className="mt-6">
                {grouped[t.value].length === 0 ? (
                  <div className="rounded-xl border border-dashed border-border p-10 text-center text-muted-foreground">
                    Nothing here yet. <Link to="/browse" className="text-primary hover:underline">Find some anime →</Link>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {grouped[t.value].map((row) => {
                      const pct = row.total_episodes ? Math.min(100, (row.progress / row.total_episodes) * 100) : 0;
                      return (
                        <Link
                          key={row.anilist_id}
                          to="/anime/$id"
                          params={{ id: String(row.anilist_id) }}
                          className="flex items-center gap-3 rounded-xl border border-border/60 bg-card/60 p-2 transition-colors hover:border-primary/50"
                        >
                          {row.cover_url && <img src={row.cover_url} alt="" className="h-20 w-14 rounded object-cover" />}
                          <div className="min-w-0 flex-1">
                            <div className="line-clamp-1 font-bold">{row.title}</div>
                            <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                              {row.format && <Badge variant="outline" className="text-[10px]">{row.format}</Badge>}
                              <span>Ep {row.progress}{row.total_episodes ? ` / ${row.total_episodes}` : ""}</span>
                              {row.score != null && (
                                <span className="flex items-center gap-1 text-primary">
                                  <Star className="size-3 fill-primary" /> {row.score}/10
                                </span>
                              )}
                            </div>
                            {row.total_episodes && (
                              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                                <div className="h-full bg-[var(--gradient-otaku)]" style={{ width: `${pct}%` }} />
                              </div>
                            )}
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        )}
      </main>
    </div>
  );
}
