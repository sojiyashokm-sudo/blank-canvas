import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/site-header";
import { LiveSchedule } from "@/components/live-schedule";

export const Route = createFileRoute("/schedule")({
  head: () => ({
    meta: [
      { title: "Live Schedule — OtakuVerse" },
      { name: "description", content: "LiveChart-style anime broadcast schedule with real-time countdowns, day filters, and streaming platform tags." },
      { property: "og:title", content: "Live Schedule — OtakuVerse" },
      { property: "og:description", content: "Real-time anime air timings, day-by-day, with countdowns and streaming tags." },
    ],
  }),
  component: SchedulePage,
});

function SchedulePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-40 left-1/2 size-[600px] -translate-x-1/2 rounded-full bg-primary/15 blur-[140px]" />
        <div className="absolute bottom-0 right-0 size-[500px] rounded-full bg-accent/15 blur-[140px]" />
      </div>
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <Button asChild variant="ghost" size="sm" className="mb-4 rounded-full text-muted-foreground hover:text-foreground">
          <Link to="/"><ArrowLeft className="mr-1.5 size-4" /> Back to home</Link>
        </Button>
        <LiveSchedule />
      </main>
    </div>
  );
}
