import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Loader2, CalendarClock } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { AnimeCard } from "@/components/anime-card";
import { browse, getWeeklySchedule, currentSeason, type AiringEntry } from "@/lib/anilist";

export const Route = createFileRoute("/airing")({
  head: () => ({
    meta: [
      { title: "Currently airing anime — OtakuVerse" },
      { name: "description", content: "This season's currently airing anime and the weekly broadcast schedule, updated live from AniList." },
      { property: "og:title", content: "Currently airing anime — OtakuVerse" },
      { property: "og:description", content: "This season's currently airing anime with next-episode countdowns." },
    ],
  }),
  component: AiringPage,
});

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function AiringPage() {
  const { season, year } = currentSeason();

  const seasonQ = useQuery({
    queryKey: ["airing-season", season, year],
    queryFn: () => browse({ season, year, sort: "POPULARITY_DESC" }, 1, 24).then((r) => r.items),
  });

  const scheduleQ = useQuery({
    queryKey: ["airing-schedule"],
    queryFn: getWeeklySchedule,
  });

  // group by day-of-week starting today
  const byDay: Record<string, AiringEntry[]> = {};
  for (const d of DAYS) byDay[d] = [];
  for (const a of scheduleQ.data ?? []) {
    const day = DAYS[new Date(a.airingAt * 1000).getDay()];
    byDay[day].push(a);
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <header className="mb-8">
          <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-primary">
            <CalendarClock className="size-4" /> {season} {year}
          </div>
          <h1 className="mt-1 text-3xl font-black tracking-tight">Currently Airing</h1>
        </header>

        {seasonQ.isLoading ? (
          <Loading />
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {(seasonQ.data ?? []).map((a) => <AnimeCard key={a.id} anime={a} />)}
          </div>
        )}

        <h2 className="mb-4 mt-12 text-sm font-bold uppercase tracking-widest text-primary">This Week's Schedule</h2>
        {scheduleQ.isLoading ? (
          <Loading />
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {DAYS.map((day) => (
              <div key={day} className="rounded-xl border border-border/60 bg-card/40 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="text-sm font-black uppercase tracking-widest">{day}</h3>
                  <span className="text-xs text-muted-foreground">{byDay[day].length}</span>
                </div>
                {byDay[day].length === 0 ? (
                  <p className="py-3 text-center text-xs text-muted-foreground">No releases</p>
                ) : (
                  <ul className="space-y-2">
                    {byDay[day].slice(0, 6).map((a) => (
                      <li key={`${a.media.id}-${a.episode}`} className="flex items-center gap-2 text-xs">
                        <img src={a.media.coverImage} alt="" className="h-10 w-7 rounded object-cover" />
                        <div className="min-w-0 flex-1">
                          <div className="line-clamp-1 font-medium">{a.media.title}</div>
                          <div className="text-muted-foreground">
                            Ep {a.episode} · {new Date(a.airingAt * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function Loading() {
  return (
    <div className="flex items-center justify-center py-20 text-muted-foreground">
      <Loader2 className="mr-2 size-5 animate-spin text-primary" /> Loading…
    </div>
  );
}
