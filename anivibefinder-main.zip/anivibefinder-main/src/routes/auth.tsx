import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — OtakuVerse" },
      { name: "description", content: "Sign in to OtakuVerse with Google to save your anime watchlist, track episode progress, and rate every show." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/list", replace: true });
    });
  }, [navigate]);

  async function handleGoogle() {
    setError(null);
    setBusy(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if (result.error) {
        setError(result.error.message || "Google sign-in failed");
        return;
      }
      if (result.redirected) return;
      navigate({ to: "/list" });
    } catch (err) {
      const message = err instanceof Error ? err.message : JSON.stringify(err);
      setError(message || "Unexpected error with Google sign-in");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4 py-10">
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-40 left-1/2 size-[600px] -translate-x-1/2 rounded-full bg-primary/20 blur-[120px]" />
        <div className="absolute bottom-0 -right-40 size-[500px] rounded-full bg-accent/20 blur-[120px]" />
      </div>

      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <div className="grid size-10 place-items-center rounded-lg bg-[var(--gradient-otaku)] shadow-[var(--neon-glow)]">
            <Sparkles className="size-5 text-white" />
          </div>
          <span className="text-xl font-black tracking-tight">
            OTAKU<span className="text-primary">VERSE</span>
          </span>
        </Link>

        <div className="rounded-2xl border border-border/60 bg-card/80 p-8 shadow-[var(--neon-glow)] backdrop-blur-xl">
          <h1 className="text-center text-2xl font-black">Enter the Verse</h1>
          <p className="mt-1 text-center text-sm text-muted-foreground">
            Track every anime you watch.
          </p>

          <div className="mt-8 flex justify-center">
            <Button
              type="button"
              onClick={handleGoogle}
              disabled={busy}
              variant="outline"
              className="w-full gap-2 rounded-full"
            >
              <svg className="size-4" viewBox="0 0 24 24"><path fill="currentColor" d="M21.35 11.1h-9.17v2.94h5.27c-.24 1.42-1.7 4.16-5.27 4.16-3.17 0-5.76-2.62-5.76-5.86s2.59-5.86 5.76-5.86c1.81 0 3.02.77 3.71 1.43l2.52-2.43C16.93 3.94 14.81 3 12.18 3 6.99 3 2.78 7.21 2.78 12.4S6.99 21.8 12.18 21.8c7.02 0 9.34-4.93 9.34-7.46 0-.5-.06-.88-.17-1.24Z" /></svg>
              {busy ? "Connecting…" : "Continue with Google"}
            </Button>
          </div>

          {error && (
            <div
              role="alert"
              className="mt-4 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-center text-sm text-destructive"
            >
              {error}
            </div>
          )}

          <p className="mt-6 text-center text-xs text-muted-foreground">
            By continuing you agree to our terms and privacy policy.
          </p>
        </div>
      </div>
    </div>
  );
}
