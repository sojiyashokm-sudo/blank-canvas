// Extended AniList GraphQL queries: detail page, browse filters, airing schedule.
// Free, no API key, CORS-enabled.

const ANILIST = "https://graphql.anilist.co";

export type MediaFormat = "TV" | "TV_SHORT" | "MOVIE" | "SPECIAL" | "OVA" | "ONA" | "MUSIC";
export type MediaSeason = "WINTER" | "SPRING" | "SUMMER" | "FALL";
export type MediaSort =
  | "POPULARITY_DESC"
  | "SCORE_DESC"
  | "SCORE"
  | "TRENDING_DESC"
  | "TRENDING"
  | "START_DATE_DESC"
  | "START_DATE"
  | "FAVOURITES_DESC"
  | "UPDATED_AT_DESC";

export type AnimeCard = {
  id: number;
  title: string;
  coverImage: string;
  bannerImage?: string | null;
  year: number | null;
  score: number | null;
  format: MediaFormat | null;
  episodes: number | null;
  genres: string[];
  isAdult: boolean;
};

export type AnimeDetail = AnimeCard & {
  idMal: number | null;
  description: string | null;
  status: string | null;
  duration: number | null;
  season: MediaSeason | null;
  studios: { name: string; main: boolean }[];
  tags: { name: string; rank: number }[];
  trailer: { id: string; site: string; thumbnail: string | null } | null;
  characters: {
    id: number;
    name: string;
    image: string | null;
    role: string;
    voiceActor?: { name: string; image: string | null; language: string } | null;
  }[];
  streamingEpisodes: { title: string; thumbnail: string | null; url: string; site: string }[];
  externalLinks: { id: number; site: string; url: string; icon: string | null; color: string | null }[];
  nextAiringEpisode: { episode: number; airingAt: number; timeUntilAiring: number } | null;
  titleVariants: { english: string | null; romaji: string | null; native: string | null };
  synonyms: string[];
  startDate: { year: number | null; month: number | null; day: number | null } | null;
  updatedAt: number | null;
};

export type EpisodeInfo = {
  number: number;
  title: string | null;
  thumbnail: string | null;
  url: string | null;
  site: string | null;
};

export async function getJikanEpisodes(malId: number): Promise<EpisodeInfo[]> {
  try {
    const res = await fetch(`https://api.jikan.moe/v4/anime/${malId}/episodes`);
    if (!res.ok) return [];
    const json = await res.json();
    const items = (json?.data ?? []) as any[];
    return items.map((e, i) => ({
      number: e.mal_id ?? i + 1,
      title: e.title ?? e.title_romanji ?? null,
      thumbnail: null,
      url: e.url ?? null,
      site: e.url ? "MyAnimeList" : null,
    }));
  } catch {
    return [];
  }
}

const CARD_FRAGMENT = `
  id
  title { romaji english native }
  coverImage { extraLarge large color }
  bannerImage
  seasonYear
  startDate { year }
  averageScore
  format
  episodes
  genres
  isAdult
`;

function cardFromNode(m: any): AnimeCard {
  return {
    id: m.id,
    title: m.title?.english || m.title?.romaji || m.title?.native || "Untitled",
    coverImage: m.coverImage?.extraLarge || m.coverImage?.large || "",
    bannerImage: m.bannerImage ?? null,
    year: m.seasonYear ?? m.startDate?.year ?? null,
    score: m.averageScore != null ? m.averageScore / 10 : null,
    format: (m.format as MediaFormat) ?? null,
    episodes: m.episodes ?? null,
    genres: m.genres ?? [],
    isAdult: !!m.isAdult,
  };
}

function stripHtml(s: string | null | undefined): string | null {
  if (!s) return null;
  return s.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
}

async function gql<T>(query: string, variables: Record<string, unknown>): Promise<T> {
  const res = await fetch(ANILIST, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ query, variables }),
  });
  if (!res.ok) throw new Error(`AniList ${res.status}`);
  const json = await res.json();
  if (json.errors) throw new Error(json.errors[0]?.message ?? "AniList error");
  return json.data as T;
}

// ─── Browse with filters ────────────────────────────────────────────────────

export type BrowseFilters = {
  search?: string;
  genres?: string[];
  year?: number;
  season?: MediaSeason;
  format?: MediaFormat;
  sort?: MediaSort;
  /** AniList popularity (users-with-media count) upper bound — filters mainstream hits. */
  popularityLesser?: number;
  /** AniList average score lower bound (0-100). */
  averageScoreGreater?: number;
};

export async function browse(
  filters: BrowseFilters,
  page = 1,
  perPage = 30,
): Promise<{ items: AnimeCard[]; hasNextPage: boolean }> {
  const vars: Record<string, unknown> = { page, perPage };
  const argParts: string[] = ["type: ANIME", "isAdult: false"];
  const varParts: string[] = ["$page: Int", "$perPage: Int"];

  if (filters.search) {
    vars.search = filters.search;
    varParts.push("$search: String");
    argParts.push("search: $search");
  }
  if (filters.genres?.length) {
    vars.genres = filters.genres;
    varParts.push("$genres: [String]");
    argParts.push("genre_in: $genres");
  }
  if (filters.year) {
    vars.year = filters.year;
    varParts.push("$year: Int");
    argParts.push("seasonYear: $year");
  }
  if (filters.season) {
    vars.season = filters.season;
    varParts.push("$season: MediaSeason");
    argParts.push("season: $season");
  }
  if (filters.format) {
    vars.format = filters.format;
    varParts.push("$format: MediaFormat");
    argParts.push("format: $format");
  }
  if (filters.popularityLesser != null) {
    vars.popularityLesser = filters.popularityLesser;
    varParts.push("$popularityLesser: Int");
    argParts.push("popularity_lesser: $popularityLesser");
  }
  if (filters.averageScoreGreater != null) {
    vars.averageScoreGreater = filters.averageScoreGreater;
    varParts.push("$averageScoreGreater: Int");
    argParts.push("averageScore_greater: $averageScoreGreater");
  }
  argParts.push(`sort: ${filters.sort ?? (filters.search ? "SEARCH_MATCH" : "POPULARITY_DESC")}`);

  const query = `
    query (${varParts.join(", ")}) {
      Page(page: $page, perPage: $perPage) {
        pageInfo { hasNextPage }
        media(${argParts.join(", ")}) { ${CARD_FRAGMENT} }
      }
    }
  `;
  const data = await gql<{ Page: { pageInfo: { hasNextPage: boolean }; media: any[] } }>(query, vars);
  return {
    items: data.Page.media.map(cardFromNode),
    hasNextPage: data.Page.pageInfo.hasNextPage,
  };
}

export const GENRES = [
  "Action", "Adventure", "Comedy", "Drama", "Ecchi", "Fantasy", "Horror",
  "Mahou Shoujo", "Mecha", "Music", "Mystery", "Psychological", "Romance",
  "Sci-Fi", "Slice of Life", "Sports", "Supernatural", "Thriller",
];

export const FORMATS: MediaFormat[] = ["TV", "TV_SHORT", "MOVIE", "SPECIAL", "OVA", "ONA"];
export const SORTS: { value: MediaSort; label: string }[] = [
  { value: "POPULARITY_DESC", label: "Most Popular" },
  { value: "SCORE_DESC", label: "Highest Rated" },
  { value: "TRENDING_DESC", label: "Trending Now" },
  { value: "START_DATE_DESC", label: "Newest" },
  { value: "FAVOURITES_DESC", label: "Most Favorited" },
];

// ─── Anime detail ───────────────────────────────────────────────────────────

export async function getAnimeDetail(id: number): Promise<AnimeDetail | null> {
  const query = `
    query ($id: Int) {
      Media(id: $id, type: ANIME) {
        ${CARD_FRAGMENT}
        idMal
        description(asHtml: false)
        status
        duration
        season
        startDate { year month day }
        updatedAt
        synonyms
        studios(isMain: true) { nodes { name } }
        tags { name rank }
        trailer { id site thumbnail }
        nextAiringEpisode { episode airingAt timeUntilAiring }
        streamingEpisodes { title thumbnail url site }
        externalLinks { id site url icon color }
        characters(sort: ROLE, perPage: 12) {
          edges {
            role
            node { id name { full } image { large } }
            voiceActors(language: JAPANESE) { name { full } image { large } languageV2 }
          }
        }
      }
    }
  `;
  const data = await gql<{ Media: any }>(query, { id });
  const m = data.Media;
  if (!m) return null;
  const card = cardFromNode(m);
  return {
    ...card,
    idMal: m.idMal ?? null,
    description: stripHtml(m.description),
    status: m.status ?? null,
    duration: m.duration ?? null,
    season: (m.season as MediaSeason) ?? null,
    studios: (m.studios?.nodes ?? []).map((s: any) => ({ name: s.name, main: true })),
    tags: (m.tags ?? []).slice(0, 12).map((t: any) => ({ name: t.name, rank: t.rank })),
    trailer: m.trailer
      ? { id: m.trailer.id, site: m.trailer.site, thumbnail: m.trailer.thumbnail ?? null }
      : null,
    nextAiringEpisode: m.nextAiringEpisode ?? null,
    streamingEpisodes: m.streamingEpisodes ?? [],
    externalLinks: m.externalLinks ?? [],
    titleVariants: {
      english: m.title?.english ?? null,
      romaji: m.title?.romaji ?? null,
      native: m.title?.native ?? null,
    },
    synonyms: (m.synonyms ?? []).filter(Boolean),
    startDate: m.startDate ?? null,
    updatedAt: m.updatedAt ?? null,
    characters: (m.characters?.edges ?? []).map((e: any) => ({
      id: e.node.id,
      name: e.node.name.full,
      image: e.node.image?.large ?? null,
      role: e.role,
      voiceActor: e.voiceActors?.[0]
        ? {
            name: e.voiceActors[0].name.full,
            image: e.voiceActors[0].image?.large ?? null,
            language: e.voiceActors[0].languageV2 ?? "Japanese",
          }
        : null,
    })),
  };
}

// ─── Recommendations ────────────────────────────────────────────────────────

export async function getRecommendations(id: number): Promise<AnimeCard[]> {
  const query = `
    query ($mediaId: Int) {
      Page(perPage: 12) {
        recommendations(mediaId: $mediaId, sort: RATING_DESC) {
          mediaRecommendation { ${CARD_FRAGMENT} }
        }
      }
    }
  `;
  try {
    const data = await gql<{ Page: { recommendations: { mediaRecommendation: any | null }[] } }>(query, { mediaId: id });
    const seen = new Set<number>();
    const out: AnimeCard[] = [];
    for (const r of data.Page.recommendations) {
      const m = r.mediaRecommendation;
      if (!m || seen.has(m.id)) continue;
      seen.add(m.id);
      out.push(cardFromNode(m));
    }
    return out;
  } catch {
    return [];
  }
}

// ─── Airing schedule ────────────────────────────────────────────────────────

export type StreamingLink = { id: number; site: string; url: string; color: string | null; icon: string | null };

export type AiringEntry = {
  airingAt: number;
  episode: number;
  media: AnimeCard;
  description: string | null;
  studios: string[];
  streaming: StreamingLink[];
  bannerImage: string | null;
};

const STREAMING_SITES = new Set([
  "Crunchyroll", "Netflix", "Hulu", "Funimation", "Hidive", "HIDIVE",
  "Amazon Prime Video", "Amazon", "Disney Plus", "Disney+", "VRV",
  "AnimeLab", "YouTube", "Bilibili", "iQIYI", "Wakanim", "Tubi",
  "Max", "HBO Max",
]);

export async function getWeeklySchedule(): Promise<AiringEntry[]> {
  const now = Math.floor(Date.now() / 1000);
  const weekEnd = now + 7 * 24 * 60 * 60;
  const query = `
    query ($start: Int, $end: Int) {
      Page(perPage: 50) {
        airingSchedules(airingAt_greater: $start, airingAt_lesser: $end, sort: TIME) {
          airingAt
          episode
          media {
            ${CARD_FRAGMENT}
            description(asHtml: false)
            bannerImage
            isAdult
            studios(isMain: true) { nodes { name } }
            externalLinks { id site url color icon }
          }
        }
      }
    }
  `;
  const data = await gql<{ Page: { airingSchedules: any[] } }>(query, { start: now, end: weekEnd });
  return data.Page.airingSchedules
    .filter((a) => a.media && !a.media.isAdult)
    .map((a) => ({
      airingAt: a.airingAt,
      episode: a.episode,
      media: cardFromNode(a.media),
      description: stripHtml(a.media.description),
      studios: (a.media.studios?.nodes ?? []).map((s: any) => s.name),
      bannerImage: a.media.bannerImage ?? null,
      streaming: (a.media.externalLinks ?? [])
        .filter((l: any) => STREAMING_SITES.has(l.site))
        .map((l: any) => ({ id: l.id, site: l.site, url: l.url, color: l.color ?? null, icon: l.icon ?? null })),
    }));
}

export function currentSeason(): { season: MediaSeason; year: number } {
  const d = new Date();
  const m = d.getMonth();
  const season: MediaSeason =
    m < 3 ? "WINTER" : m < 6 ? "SPRING" : m < 9 ? "SUMMER" : "FALL";
  return { season, year: d.getFullYear() };
}

// ─── Season-wide schedule (LiveChart-style) ─────────────────────────────────

export type SeasonEntry = {
  media: AnimeCard;
  description: string | null;
  studios: string[];
  streaming: StreamingLink[];
  bannerImage: string | null;
  status: string | null; // RELEASING | FINISHED | NOT_YET_RELEASED | CANCELLED | HIATUS
  startDate: { year: number | null; month: number | null; day: number | null } | null;
  nextAiringEpisode: { episode: number; airingAt: number } | null;
};

const SEASON_FRAGMENT = `
  ${CARD_FRAGMENT}
  description(asHtml: false)
  bannerImage
  isAdult
  status
  startDate { year month day }
  nextAiringEpisode { episode airingAt }
  studios(isMain: true) { nodes { name } }
  externalLinks { id site url color icon }
`;

function seasonEntryFromNode(m: any): SeasonEntry {
  return {
    media: cardFromNode(m),
    description: stripHtml(m.description),
    studios: (m.studios?.nodes ?? []).map((s: any) => s.name),
    bannerImage: m.bannerImage ?? null,
    status: m.status ?? null,
    startDate: m.startDate ?? null,
    nextAiringEpisode: m.nextAiringEpisode ?? null,
    streaming: (m.externalLinks ?? [])
      .filter((l: any) => STREAMING_SITES.has(l.site))
      .map((l: any) => ({ id: l.id, site: l.site, url: l.url, color: l.color ?? null, icon: l.icon ?? null })),
  };
}

export async function getSeasonAnime(
  season: MediaSeason,
  year: number,
  page = 1,
  perPage = 50,
): Promise<{ items: SeasonEntry[]; hasNextPage: boolean }> {
  const query = `
    query ($season: MediaSeason, $year: Int, $page: Int, $perPage: Int) {
      Page(page: $page, perPage: $perPage) {
        pageInfo { hasNextPage }
        media(type: ANIME, isAdult: false, season: $season, seasonYear: $year, sort: POPULARITY_DESC) {
          ${SEASON_FRAGMENT}
        }
      }
    }
  `;
  const data = await gql<{ Page: { pageInfo: { hasNextPage: boolean }; media: any[] } }>(
    query, { season, year, page, perPage },
  );
  return {
    items: data.Page.media.filter((m) => !m.isAdult).map(seasonEntryFromNode),
    hasNextPage: data.Page.pageInfo.hasNextPage,
  };
}

/** Announced/upcoming anime without a confirmed start date (TBA). */
export async function getUnscheduledUpcoming(
  page = 1,
  perPage = 30,
): Promise<{ items: SeasonEntry[]; hasNextPage: boolean }> {
  const query = `
    query ($page: Int, $perPage: Int) {
      Page(page: $page, perPage: $perPage) {
        pageInfo { hasNextPage }
        media(
          type: ANIME, isAdult: false, status: NOT_YET_RELEASED,
          sort: POPULARITY_DESC
        ) {
          ${SEASON_FRAGMENT}
        }
      }
    }
  `;
  const data = await gql<{ Page: { pageInfo: { hasNextPage: boolean }; media: any[] } }>(
    query, { page, perPage },
  );
  // Keep only those without a concrete start date (TBA / unscheduled).
  const items = data.Page.media
    .filter((m) => !m.isAdult)
    .map(seasonEntryFromNode)
    .filter((e) => !(e.startDate?.year && e.startDate?.month && e.startDate?.day));
  return { items, hasNextPage: data.Page.pageInfo.hasNextPage };
}

export const SEASONS: MediaSeason[] = ["WINTER", "SPRING", "SUMMER", "FALL"];

export function seasonYearRange(): number[] {
  const cur = new Date().getFullYear();
  const years: number[] = [];
  for (let y = cur + 2; y >= 1980; y--) years.push(y);
  return years;
}

export type AiringInfoForId = {
  id: number;
  title: string;
  coverImage: string;
  nextAiringEpisode: { episode: number; airingAt: number } | null;
};

export async function getAiringInfoForIds(ids: number[]): Promise<AiringInfoForId[]> {
  if (ids.length === 0) return [];
  const query = `
    query ($ids: [Int]) {
      Page(perPage: 50) {
        media(id_in: $ids, type: ANIME) {
          id
          title { english romaji }
          coverImage { large }
          nextAiringEpisode { episode airingAt }
        }
      }
    }
  `;
  const data = await gql<{ Page: { media: any[] } }>(query, { ids });
  return data.Page.media.map((m) => ({
    id: m.id,
    title: m.title?.english ?? m.title?.romaji ?? "Anime",
    coverImage: m.coverImage?.large ?? "",
    nextAiringEpisode: m.nextAiringEpisode ?? null,
  }));
}


