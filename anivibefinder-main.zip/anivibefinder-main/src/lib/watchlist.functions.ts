import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const StatusEnum = z.enum(["watching", "completed", "planning", "paused", "dropped"]);

const UpsertSchema = z.object({
  anilist_id: z.number().int().positive(),
  status: StatusEnum,
  progress: z.number().int().min(0).default(0),
  score: z.number().int().min(1).max(10).nullable().optional(),
  notes: z.string().max(2000).nullable().optional(),
  title: z.string(),
  cover_url: z.string().nullable().optional(),
  total_episodes: z.number().int().nullable().optional(),
  format: z.string().nullable().optional(),
});

export const upsertWatchlistEntry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => UpsertSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("watchlist")
      .upsert(
        { ...data, user_id: userId, score: data.score ?? null, notes: data.notes ?? null },
        { onConflict: "user_id,anilist_id" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const removeWatchlistEntry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ anilist_id: z.number().int() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("watchlist")
      .delete()
      .eq("user_id", context.userId)
      .eq("anilist_id", data.anilist_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getMyWatchlist = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("watchlist")
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getWatchlistEntry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ anilist_id: z.number().int() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("watchlist")
      .select("*")
      .eq("user_id", context.userId)
      .eq("anilist_id", data.anilist_id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });
