export type Palette = {
  id: string;
  label: string;
  gradientLabel: string;
  gradientFrom: string;
  gradientTo: string;
  swatches: string[]; // exactly 7, dark -> light
};

// Compact 7-step palettes. Swatch labels are derived from step index in the UI.
export const PALETTES: Palette[] = [
  {
    id: "noir",
    label: "Noir Minimal",
    gradientLabel: "Pitch Black to Very Light Grey",
    gradientFrom: "#000000",
    gradientTo: "#F5F5F6",
    swatches: ["#000000", "#1A1A1A", "#333333", "#666666", "#999999", "#CCCCCC", "#F5F5F6"],
  },
  {
    id: "crimson",
    label: "Crimson Minimal",
    gradientLabel: "Deep Burgundy to Alabaster Blush",
    gradientFrom: "#1A0505",
    gradientTo: "#FFF0F0",
    swatches: ["#1A0505", "#330A0A", "#661414", "#991F1F", "#CC4444", "#FFA3A3", "#FFF0F0"],
  },
  {
    id: "cobalt",
    label: "Cobalt Minimal",
    gradientLabel: "Abyss Blue to Frost White",
    gradientFrom: "#050C1A",
    gradientTo: "#F0F4FA",
    swatches: ["#050C1A", "#0A1833", "#143066", "#2952A3", "#7094DB", "#C2D1F0", "#F0F4FA"],
  },
  {
    id: "sage",
    label: "Sage Minimal",
    gradientLabel: "Deep Forest to Alabaster Mint",
    gradientFrom: "#081A05",
    gradientTo: "#F0FFF0",
    swatches: ["#081A05", "#10330A", "#206614", "#3D992E", "#6BC25E", "#A3FFA3", "#F0FFF0"],
  },
  {
    id: "plum",
    label: "Midnight Plum",
    gradientLabel: "Deep Eggplant to Haze White",
    gradientFrom: "#12051A",
    gradientTo: "#FAF5FF",
    swatches: ["#12051A", "#240A33", "#491466", "#7229A3", "#AC5CD6", "#DDB3FF", "#FAF5FF"],
  },
  {
    id: "amber",
    label: "Amber Minimal",
    gradientLabel: "Dark Bronze to Pale Straw",
    gradientFrom: "#1A1605",
    gradientTo: "#FFFDF0",
    swatches: ["#1A1605", "#332B0A", "#665514", "#99801F", "#CCAB29", "#FFE885", "#FFFDF0"],
  },
  {
    id: "orange",
    label: "Ember Orange",
    gradientLabel: "Deep Rust to Cream Peach",
    gradientFrom: "#1A0A00",
    gradientTo: "#FFF3E6",
    swatches: ["#1A0A00", "#331500", "#662A00", "#994000", "#CC6620", "#FFA366", "#FFF3E6"],
  },
  {
    id: "pink",
    label: "Blush Pink",
    gradientLabel: "Deep Currant to Petal White",
    gradientFrom: "#1A0510",
    gradientTo: "#FFF5FA",
    swatches: ["#1A0510", "#330A20", "#661440", "#992E67", "#CC5C96", "#FFADD6", "#FFF5FA"],
  },
  {
    id: "brown",
    label: "Espresso Brown",
    gradientLabel: "Dark Cacao to Alabaster Almond",
    gradientFrom: "#120B05",
    gradientTo: "#FFFBF7",
    swatches: ["#120B05", "#24160A", "#472B14", "#6E4B2B", "#9E7B5C", "#CCB094", "#FFFBF7"],
  },
  {
    id: "teal",
    label: "Deep Teal",
    gradientLabel: "Abyss Teal to Ice Mint",
    gradientFrom: "#051A1A",
    gradientTo: "#F0FFFF",
    swatches: ["#051A1A", "#0A3333", "#146666", "#1F9999", "#52CCCC", "#A3FFFF", "#F0FFFF"],
  },
  {
    id: "gold",
    label: "Vintage Gold",
    gradientLabel: "Antique Bronze to Ivory Shimmer",
    gradientFrom: "#1A1700",
    gradientTo: "#FFFFE6",
    swatches: ["#1A1700", "#332D00", "#665A00", "#998700", "#CCB400", "#FFE633", "#FFFFE6"],
  },
  {
    id: "beige",
    label: "Linen Beige",
    gradientLabel: "Dark Khaki to Chalky Ivory",
    gradientFrom: "#1A1812",
    gradientTo: "#FFFDF5",
    swatches: ["#1A1812", "#332F24", "#665F49", "#998E6E", "#CCBE93", "#E6DCBA", "#FFFDF5"],
  },
  {
    id: "rust",
    label: "Oxidation Rust",
    gradientLabel: "Deep Iron to Parchment Glow",
    gradientFrom: "#140700",
    gradientTo: "#FFEFE6",
    swatches: ["#140700", "#2E1100", "#5C2200", "#8A3300", "#B85314", "#E0864D", "#FFEFE6"],
  },
  {
    id: "olive",
    label: "Olive Drab",
    gradientLabel: "Army Base to Khaki Glow",
    gradientFrom: "#14160D",
    gradientTo: "#F4F7E6",
    swatches: ["#14160D", "#292D1A", "#525A35", "#7B874F", "#A4B46A", "#C9D69B", "#F4F7E6"],
  },
  {
    id: "slate",
    label: "Cyber Slate",
    gradientLabel: "Off-Black Cyan to Bright Steel",
    gradientFrom: "#0D1117",
    gradientTo: "#C9D1D9",
    swatches: ["#0D1117", "#161B22", "#21262D", "#30363D", "#8B949E", "#B1BAC4", "#C9D1D9"],
  },
];
