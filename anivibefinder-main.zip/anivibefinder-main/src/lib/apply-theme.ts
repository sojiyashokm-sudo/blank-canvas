import { PALETTES, type Palette } from "@/lib/theme-palettes";

export const PREFS_KEY = "otakuverse:prefs";
export const THEME_EVENT = "otakuverse:theme-change";

function isDark(hex: string): boolean {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.55;
}

export function getPalette(id: string): Palette {
  return PALETTES.find((p) => p.id === id) ?? PALETTES[0];
}

export function applyPalette(id: string) {
  if (typeof document === "undefined") return;
  const p = getPalette(id);
  const [s0, s1, s2, s3, s4, s5, s6] = p.swatches;
  const accentFg = isDark(s4) ? s6 : s0;
  const cardFg = isDark(s1) ? s6 : s0;

  const vars: Record<string, string> = {
    // Requested custom aliases
    "--color-bg": s0,
    "--color-card": s1,
    "--color-border": s2,
    "--color-muted": s3,
    "--color-accent": s4,
    "--color-highlight": s5,
    "--color-text": s6,

    // shadcn / tailwind tokens (drive the whole app)
    "--background": s0,
    "--foreground": cardFg,
    "--card": s1,
    "--card-foreground": cardFg,
    "--popover": s1,
    "--popover-foreground": cardFg,
    "--muted": s1,
    "--muted-foreground": s5,
    "--border": s2,
    "--input": s2,
    "--secondary": s2,
    "--secondary-foreground": cardFg,
    "--accent": s4,
    "--accent-foreground": accentFg,
    "--primary": s4,
    "--primary-foreground": accentFg,
    "--ring": s4,
    "--sidebar": s0,
    "--sidebar-foreground": cardFg,
    "--sidebar-accent": s1,
    "--sidebar-accent-foreground": cardFg,
    "--sidebar-border": s2,
    "--sidebar-primary": s4,
    "--sidebar-primary-foreground": accentFg,
    "--sidebar-ring": s4,
    "--gradient-otaku": s4,
  };

  const root = document.documentElement;
  for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v);
  root.dataset.theme = p.id;
}

export function loadThemeId(): string {
  if (typeof window === "undefined") return "noir";
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return "noir";
    const parsed = JSON.parse(raw);
    return typeof parsed?.theme === "string" ? parsed.theme : "noir";
  } catch {
    return "noir";
  }
}

export function setTheme(id: string) {
  applyPalette(id);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent(THEME_EVENT, { detail: id }));
  }
}
