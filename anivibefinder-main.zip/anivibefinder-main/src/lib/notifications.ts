// Client-side helpers for native Notification API (foreground only).

export const NOTIF_ENABLED_KEY = "otakuverse:notifications-enabled";
export const NOTIF_SEEN_KEY = "otakuverse:notified-episodes";

export function notificationsSupported(): boolean {
  return typeof window !== "undefined" && "Notification" in window;
}

export function currentPermission(): NotificationPermission | "unsupported" {
  if (!notificationsSupported()) return "unsupported";
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<NotificationPermission | "unsupported"> {
  if (!notificationsSupported()) return "unsupported";
  if (Notification.permission === "granted" || Notification.permission === "denied") {
    return Notification.permission;
  }
  return await Notification.requestPermission();
}

export function isEnabled(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(NOTIF_ENABLED_KEY) === "1";
}

export function setEnabled(v: boolean) {
  if (typeof window === "undefined") return;
  localStorage.setItem(NOTIF_ENABLED_KEY, v ? "1" : "0");
  window.dispatchEvent(new StorageEvent("storage", { key: NOTIF_ENABLED_KEY }));
}

type SeenMap = Record<string, number>;
function readSeen(): SeenMap {
  try {
    return JSON.parse(localStorage.getItem(NOTIF_SEEN_KEY) ?? "{}");
  } catch {
    return {};
  }
}
function writeSeen(m: SeenMap) {
  localStorage.setItem(NOTIF_SEEN_KEY, JSON.stringify(m));
}

/** Returns the last episode we already notified about for this anime (0 if none). */
export function lastNotifiedEpisode(anilistId: number): number {
  return readSeen()[String(anilistId)] ?? 0;
}

export function markNotified(anilistId: number, episode: number) {
  const m = readSeen();
  m[String(anilistId)] = episode;
  writeSeen(m);
}

export function fireEpisodeNotification(opts: {
  anilistId: number;
  title: string;
  episode: number;
  coverImage?: string;
}) {
  if (!notificationsSupported() || Notification.permission !== "granted") return;
  const n = new Notification(`New episode: ${opts.title}`, {
    body: `Episode ${opts.episode} just aired. Tap to open.`,
    icon: opts.coverImage || "/icon-192.png",
    badge: "/icon-192.png",
    tag: `ep-${opts.anilistId}-${opts.episode}`,
  });
  n.onclick = () => {
    window.focus();
    window.location.href = `/anime/${opts.anilistId}`;
    n.close();
  };
}
