
CREATE TYPE public.watch_status AS ENUM ('watching', 'completed', 'planning', 'paused', 'dropped');

CREATE TABLE public.watchlist (
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  anilist_id INTEGER NOT NULL,
  status public.watch_status NOT NULL DEFAULT 'planning',
  progress INTEGER NOT NULL DEFAULT 0,
  score INTEGER,
  notes TEXT,
  title TEXT NOT NULL,
  cover_url TEXT,
  total_episodes INTEGER,
  format TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, anilist_id),
  CHECK (score IS NULL OR (score BETWEEN 1 AND 10)),
  CHECK (progress >= 0)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.watchlist TO authenticated;
GRANT ALL ON public.watchlist TO service_role;

ALTER TABLE public.watchlist ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own watchlist" ON public.watchlist
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own watchlist" ON public.watchlist
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own watchlist" ON public.watchlist
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own watchlist" ON public.watchlist
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX watchlist_user_status_idx ON public.watchlist(user_id, status);

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER watchlist_set_updated_at BEFORE UPDATE ON public.watchlist
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
